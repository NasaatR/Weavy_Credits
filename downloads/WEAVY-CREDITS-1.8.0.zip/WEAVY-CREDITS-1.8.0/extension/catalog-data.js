// Public numeric tariff data: all ten official comparison tables. See docs/PRICING-RESEARCH.md.
export const BUILTIN_CATALOG = {
  "version": "2026-10-27-llm",
  "aliasesUpdatedAt": "2026-10-27",
  "checkedAt": "2026-09-22",
  "variantsUpdatedAt": "2026-10-23",
  "officialCount": 147,
  "variantCount": 40,
  "textModelCount": 360,
  "entries": [
    {
      "name": "ChatGPT Images 2.0",
      "priceText": "1-37",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "ChatGPT Image 2.0",
        "ChatGPT Images 2.0",
        "GPT Image 2",
        "GPT Images 2",
        "gpt-image-2",
        "gpt_image_2",
        "gpt image 2"
      ],
      "category": "image",
      "provenance": "official-help",
      "kind": "range",
      "min": 1,
      "max": 37,
      "previousPrice": {
        "kind": "dynamic",
        "min": 9,
        "max": 37,
        "note": "Предыдущий каталог отличается; его цены не считаются текущими"
      },
      "parameterRules": {
        "options": [
          {
            "credits": 9,
            "when": {
              "quality": "medium"
            }
          },
          {
            "credits": 37,
            "when": {
              "quality": "high"
            }
          }
        ],
        "source": "Предоставленный анализатор 0.20.0",
        "sourceDate": "2026-07-28",
        "verifiedCurrent": false
      }
    },
    {
      "name": "Reve",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Higgsfield Image",
      "priceText": "21",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 21,
      "max": 21
    },
    {
      "name": "GPT Image 1",
      "priceText": "8",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "gpt-image-1"
      ],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 8,
      "max": 8
    },
    {
      "name": "Imagen 4",
      "priceText": "6",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 6,
      "max": 6
    },
    {
      "name": "Imagen 3",
      "priceText": "6",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 6,
      "max": 6
    },
    {
      "name": "Imagen 3 Fast",
      "priceText": "3",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 3,
      "max": 3
    },
    {
      "name": "Flux 2 Pro",
      "priceText": "5",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 5,
      "max": 5
    },
    {
      "name": "Flux 2 Flex",
      "priceText": "14",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 14,
      "max": 14
    },
    {
      "name": "Flux 2 Dev LoRA",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Flux 1.1 Ultra",
      "priceText": "7",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Flux Ultra 1.1",
        "flux-1.1-ultra"
      ],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 7,
      "max": 7
    },
    {
      "name": "Flux Pro 1.1",
      "priceText": "5",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Flux 1.1 Pro",
        "flux-1.1-pro"
      ],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 5,
      "max": 5
    },
    {
      "name": "Flux Fast",
      "priceText": "0.4",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "flux-fast"
      ],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 0.4,
      "max": 0.4
    },
    {
      "name": "Flux Dev LoRA",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Recraft V3",
      "priceText": "5",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 5,
      "max": 5
    },
    {
      "name": "Mystic",
      "priceText": "12",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 12,
      "max": 12
    },
    {
      "name": "Ideogram V3",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Ideogram V3 Character",
      "priceText": "15",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 15,
      "max": 15
    },
    {
      "name": "Stable Diffusion 3.5",
      "priceText": "8",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "SD 3.5",
        "SD3.5"
      ],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 8,
      "max": 8
    },
    {
      "name": "Minimax Image 01",
      "priceText": "1",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "MiniMax Image 01"
      ],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 1,
      "max": 1
    },
    {
      "name": "Bria",
      "priceText": "6",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 6,
      "max": 6
    },
    {
      "name": "Dalle 3",
      "priceText": "5",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "DALL-E 3",
        "DALL·E 3"
      ],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 5,
      "max": 5
    },
    {
      "name": "Luma Photon",
      "priceText": "2",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 2,
      "max": 2
    },
    {
      "name": "Nvidia Sana",
      "priceText": "0.2",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 0.2,
      "max": 0.2
    },
    {
      "name": "Nvidia Consistory",
      "priceText": "5",
      "source": "https://help.weavy.ai/en/articles/12284752-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 5,
      "max": 5
    },
    {
      "name": "ChatGPT Images 2.0 Edit",
      "priceText": "1-37",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "ChatGPT Image 2.0 Edit",
        "ChatGPT Images 2.0 Edit",
        "GPT Image 2 Edit",
        "GPT Images 2 Edit",
        "gpt-image-2/edit",
        "openai/gpt-image-2/edit",
        "gpt_image_2_edit",
        "gpt image 2 edit",
        "gpt image 2/gpt/image",
        "gpt-image-2/gpt/image"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "range",
      "min": 1,
      "max": 37,
      "previousPrice": {
        "kind": "dynamic",
        "min": 9,
        "max": 37,
        "note": "Предыдущий каталог отличается; его цены не считаются текущими"
      },
      "parameterRules": {
        "options": [
          {
            "credits": 9,
            "when": {
              "quality": "medium"
            }
          },
          {
            "credits": 37,
            "when": {
              "quality": "high"
            }
          }
        ],
        "source": "Предоставленный анализатор 0.20.0",
        "sourceDate": "2026-07-28",
        "verifiedCurrent": false
      }
    },
    {
      "name": "Gemini 3.1 Flash (Nano Banana 2)",
      "priceText": "4-18",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Nano Banana 2",
        "Gemini 3.1 Flash",
        "fal-ai/nano-banana-2/edit",
        "nano-banana-2/edit"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "range",
      "min": 4,
      "max": 18,
      "previousPrice": {
        "kind": "dynamic",
        "min": 6,
        "max": 13.5,
        "note": "Предыдущий каталог отличается; его цены не считаются текущими"
      },
      "parameterRules": {
        "options": [
          {
            "credits": 6,
            "when": {
              "resolution": "1k"
            }
          },
          {
            "credits": 9,
            "when": {
              "resolution": "2k"
            }
          },
          {
            "credits": 13.5,
            "when": {
              "resolution": "4k"
            }
          }
        ],
        "source": "Предоставленный анализатор 0.20.0",
        "sourceDate": "2026-07-28",
        "verifiedCurrent": false
      }
    },
    {
      "name": "Gemini 3 Pro",
      "priceText": "15-30",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Nano Banana Pro",
        "Gemini 3 (Nano Banana Pro)",
        "Gemini 3 Pro Image",
        "fal-ai/nano-banana-pro/edit",
        "nano-banana-pro/edit"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "range",
      "min": 15,
      "max": 30,
      "previousPrice": {
        "kind": "dynamic",
        "min": 11,
        "max": 23,
        "note": "Предыдущий каталог отличается; его цены не считаются текущими"
      },
      "parameterRules": {
        "options": [
          {
            "credits": 11,
            "when": {
              "resolution": "1k"
            }
          },
          {
            "credits": 11,
            "when": {
              "resolution": "2k"
            }
          },
          {
            "credits": 23,
            "when": {
              "resolution": "4k"
            }
          }
        ],
        "source": "Предоставленный анализатор 0.20.0",
        "sourceDate": "2026-07-28",
        "verifiedCurrent": false
      }
    },
    {
      "name": "Seedream V5 Edit",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Seedream V5",
        "Seedream V5.0 Edit",
        "Seedream 5.0 Edit"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Seedream V4.5 Edit",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Reve Edit",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Qwen Image Edit 2511",
      "priceText": "10",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 10,
      "max": 10
    },
    {
      "name": "Qwen Edit Image Plus",
      "priceText": "3",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 3,
      "max": 3
    },
    {
      "name": "Flux 2 Inpaint Klein 9B",
      "priceText": "10",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 10,
      "max": 10
    },
    {
      "name": "Runway Gen-4 Image",
      "priceText": "6",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Runway Gen- 4 Image"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 6,
      "max": 6
    },
    {
      "name": "Seedream V4 Edit",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Klux Kontext",
      "priceText": "3",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Flux Kontext"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 3,
      "max": 3
    },
    {
      "name": "Flux Kontext Multi Image",
      "priceText": "10",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 10,
      "max": 10
    },
    {
      "name": "Flux Kontext LoRA",
      "priceText": "12",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 12,
      "max": 12
    },
    {
      "name": "GPT Image 1.5 Edit",
      "priceText": "7",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "gpt-image-1.5-edit",
        "GPT Image 1.5",
        "gpt-image-1.5"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 7,
      "max": 7
    },
    {
      "name": "GPT Image 1 Edit",
      "priceText": "8",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "gpt-image-1-edit"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 8,
      "max": 8
    },
    {
      "name": "SeedEdit 3.0",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Gemini 2.0 Flash",
      "priceText": "0.1",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 0.1,
      "max": 0.1
    },
    {
      "name": "Flux 2 Max",
      "priceText": "10",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Flux 2 Max Edit",
        "fal-ai/flux-2-max/edit"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 10,
      "max": 10,
      "excludedAliases": [
        "fal-ai/flux-2-max"
      ],
      "aliasSources": [
        "https://fal.ai/models/fal-ai/flux-2-max/edit/api",
        "https://fal.ai/models/fal-ai/flux-2-max/api"
      ],
      "aliasesCheckedAt": "2026-10-27"
    },
    {
      "name": "Flux Fill Pro",
      "priceText": "6",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 6,
      "max": 6
    },
    {
      "name": "Flux Dev LoRA Inpaint",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Ideogram V3 Inpaint",
      "priceText": "11",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 11,
      "max": 11
    },
    {
      "name": "Ideogram V2 Inpaint",
      "priceText": "10",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 10,
      "max": 10
    },
    {
      "name": "SD3 Inpaint",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Stable Diffusion 3 Inpaint"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Bria Inpaint",
      "priceText": "5",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 5,
      "max": 5
    },
    {
      "name": "Flux Pro Outpaint",
      "priceText": "6",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 6,
      "max": 6
    },
    {
      "name": "SD3 Outpaint",
      "priceText": "5",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Stable Diffusion 3 Outpaint"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 5,
      "max": 5
    },
    {
      "name": "SD3 Remove Background",
      "priceText": "2",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 2,
      "max": 2
    },
    {
      "name": "Bria Remove Background",
      "priceText": "0.6",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 0.6,
      "max": 0.6
    },
    {
      "name": "SD3 Content-Aware Fill",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Kolors Virtual Try On",
      "priceText": "8",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 8,
      "max": 8
    },
    {
      "name": "Replace Background",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Bria Content Aware-Fill",
      "priceText": "5",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Bria Content-Aware Fill"
      ],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 5,
      "max": 5
    },
    {
      "name": "Bria Replace Background",
      "priceText": "2",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 2,
      "max": 2
    },
    {
      "name": "Relight 2.0",
      "priceText": "10",
      "source": "https://help.weavy.ai/en/articles/12343904-edit-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "image-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 10,
      "max": 10
    },
    {
      "name": "Seedance 2.0",
      "priceText": "Fast - 4s 116 / 15s 443 Standard - 4s 145 / 15s 552 1080p prices are different",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 116,
          "when": {
            "mode": "fast",
            "duration": 4
          }
        },
        {
          "credits": 443,
          "when": {
            "mode": "fast",
            "duration": 15
          }
        },
        {
          "credits": 145,
          "when": {
            "mode": "standard",
            "duration": 4
          }
        },
        {
          "credits": 552,
          "when": {
            "mode": "standard",
            "duration": 15
          }
        }
      ],
      "min": 116,
      "max": 552,
      "unsupportedResolutions": [
        "1080",
        "1080p"
      ]
    },
    {
      "name": "Seedance 2.0 Reference",
      "priceText": "Fast - 4s 116 / 15s 443 Standard - 4s 145 / 15s 552 1080p prices are different",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 116,
          "when": {
            "mode": "fast",
            "duration": 4
          }
        },
        {
          "credits": 443,
          "when": {
            "mode": "fast",
            "duration": 15
          }
        },
        {
          "credits": 145,
          "when": {
            "mode": "standard",
            "duration": 4
          }
        },
        {
          "credits": 552,
          "when": {
            "mode": "standard",
            "duration": 15
          }
        }
      ],
      "min": 116,
      "max": 552,
      "unsupportedResolutions": [
        "1080",
        "1080p"
      ]
    },
    {
      "name": "Kling 3",
      "priceText": "Pro - 3s 80 / 15s 440 Standard - 3s 60 / 15s 300",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 80,
          "when": {
            "mode": "pro",
            "duration": 3
          }
        },
        {
          "credits": 440,
          "when": {
            "mode": "pro",
            "duration": 15
          }
        },
        {
          "credits": 60,
          "when": {
            "mode": "standard",
            "duration": 3
          }
        },
        {
          "credits": 300,
          "when": {
            "mode": "standard",
            "duration": 15
          }
        }
      ],
      "min": 60,
      "max": 440
    },
    {
      "name": "Seedance V1.5 Pro",
      "priceText": "25-74",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "range",
      "min": 25,
      "max": 74
    },
    {
      "name": "Wan 2.5",
      "priceText": "55",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 55,
      "max": 55
    },
    {
      "name": "Grok Imagine Video",
      "priceText": "36-90",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "range",
      "min": 36,
      "max": 90
    },
    {
      "name": "Sora 2",
      "priceText": "Normal - 96 Pro - 288",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 96,
          "when": {
            "mode": "normal"
          }
        },
        {
          "credits": 288,
          "when": {
            "mode": "pro"
          }
        }
      ],
      "min": 96,
      "max": 288
    },
    {
      "name": "Wan 2.2",
      "priceText": "66",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 66,
      "max": 66
    },
    {
      "name": "LTX 2 Video",
      "priceText": "Fast 6s- 50 Fast 8s- 100 Fast 10s- 200 Pro 6s- 70 Pro 8s- 140 Pro 10s- 280",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 50,
          "when": {
            "mode": "fast",
            "duration": 6
          }
        },
        {
          "credits": 100,
          "when": {
            "mode": "fast",
            "duration": 8
          }
        },
        {
          "credits": 200,
          "when": {
            "mode": "fast",
            "duration": 10
          }
        },
        {
          "credits": 70,
          "when": {
            "mode": "pro",
            "duration": 6
          }
        },
        {
          "credits": 140,
          "when": {
            "mode": "pro",
            "duration": 8
          }
        },
        {
          "credits": 280,
          "when": {
            "mode": "pro",
            "duration": 10
          }
        }
      ],
      "min": 50,
      "max": 280
    },
    {
      "name": "Moonvalley",
      "priceText": "5s -165 10s - 330",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 165,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 330,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 165,
      "max": 330
    },
    {
      "name": "Veo 3.1 Text to Image",
      "priceText": "Fast - 120 Standard - 320",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Veo 3.1 Text to Video"
      ],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 120,
          "when": {
            "mode": "fast"
          }
        },
        {
          "credits": 320,
          "when": {
            "mode": "standard"
          }
        }
      ],
      "min": 120,
      "max": 320
    },
    {
      "name": "Veo 3.1 Image to Video",
      "priceText": "Fast - 120 Standard - 320",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 120,
          "when": {
            "mode": "fast"
          }
        },
        {
          "credits": 320,
          "when": {
            "mode": "standard"
          }
        }
      ],
      "min": 120,
      "max": 320
    },
    {
      "name": "Veo 3 Text to Image",
      "priceText": "Fast - 120 Standard - 320",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Veo 3 Text to Video"
      ],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 120,
          "when": {
            "mode": "fast"
          }
        },
        {
          "credits": 320,
          "when": {
            "mode": "standard"
          }
        }
      ],
      "min": 120,
      "max": 320
    },
    {
      "name": "Veo 3 Image to Video",
      "priceText": "Fast - 120 Standard - 320",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 120,
          "when": {
            "mode": "fast"
          }
        },
        {
          "credits": 320,
          "when": {
            "mode": "standard"
          }
        }
      ],
      "min": 120,
      "max": 320
    },
    {
      "name": "Veo 2",
      "priceText": "5s - 300 8s - 400",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 300,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 400,
          "when": {
            "duration": 8
          }
        }
      ],
      "min": 300,
      "max": 400
    },
    {
      "name": "Seedance V1.0",
      "priceText": "Lite 5s - 18 Lite 10s - 36 Pro 5s - 88 Pro 10s - 176",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Seedance 1.0"
      ],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 18,
          "when": {
            "mode": "lite",
            "duration": 5
          }
        },
        {
          "credits": 36,
          "when": {
            "mode": "lite",
            "duration": 10
          }
        },
        {
          "credits": 88,
          "when": {
            "mode": "pro",
            "duration": 5
          }
        },
        {
          "credits": 176,
          "when": {
            "mode": "pro",
            "duration": 10
          }
        }
      ],
      "min": 18,
      "max": 176
    },
    {
      "name": "Pixverse V4.5",
      "priceText": "5s - 60 10s - 90",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "PixVerse V4.5"
      ],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 60,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 90,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 60,
      "max": 90
    },
    {
      "name": "Runway Gen-4.5",
      "priceText": "5s - 70 8s - 112 10s - 140",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 70,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 112,
          "when": {
            "duration": 8
          }
        },
        {
          "credits": 140,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 70,
      "max": 140
    },
    {
      "name": "Runway Gen-4 Turbo",
      "priceText": "5s - 30 10s - 60",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Runway Gen-4Turbo"
      ],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 30,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 60,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 30,
      "max": 60
    },
    {
      "name": "Runway Gen-4",
      "priceText": "2s - 28 4s - 56 5s - 70 6s - 84 7s - 98 8s - 112 9s - 126 10s -140",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 28,
          "when": {
            "duration": 2
          }
        },
        {
          "credits": 56,
          "when": {
            "duration": 4
          }
        },
        {
          "credits": 70,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 84,
          "when": {
            "duration": 6
          }
        },
        {
          "credits": 98,
          "when": {
            "duration": 7
          }
        },
        {
          "credits": 112,
          "when": {
            "duration": 8
          }
        },
        {
          "credits": 126,
          "when": {
            "duration": 9
          }
        },
        {
          "credits": 140,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 28,
      "max": 140
    },
    {
      "name": "Runway Gen-3",
      "priceText": "5s - 30 10s - 60",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 30,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 60,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 30,
      "max": 60
    },
    {
      "name": "Kling 1.6",
      "priceText": "Standard 5s - 18 Standard 10s - 36 Pro 5s - 37.5 Pro 10s - 75",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 18,
          "when": {
            "mode": "standard",
            "duration": 5
          }
        },
        {
          "credits": 36,
          "when": {
            "mode": "standard",
            "duration": 10
          }
        },
        {
          "credits": 37.5,
          "when": {
            "mode": "pro",
            "duration": 5
          }
        },
        {
          "credits": 75,
          "when": {
            "mode": "pro",
            "duration": 10
          }
        }
      ],
      "min": 18,
      "max": 75
    },
    {
      "name": "Kling Video",
      "priceText": "2.1 Standard 5s- 25 2.1 Standard 10s- 50 2.1 Pro 5s - 45 2.1 Pro 10s - 90 2.1 Master 5s - 90 2.1 Master 10s - 280 2.5 Turbo Pro 5s - 35 2.5 Turbo Pro 10s - 70 2.6 Pro 5s - 120 2.6 Pro 5s - 180",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 25,
          "when": {
            "text": "2.1 standard",
            "duration": 5
          }
        },
        {
          "credits": 50,
          "when": {
            "text": "2.1 standard",
            "duration": 10
          }
        },
        {
          "credits": 45,
          "when": {
            "text": "2.1 pro",
            "duration": 5
          }
        },
        {
          "credits": 90,
          "when": {
            "text": "2.1 pro",
            "duration": 10
          }
        },
        {
          "credits": 90,
          "when": {
            "text": "2.1 master",
            "duration": 5
          }
        },
        {
          "credits": 280,
          "when": {
            "text": "2.1 master",
            "duration": 10
          }
        },
        {
          "credits": 35,
          "when": {
            "text": "2.5 turbo pro",
            "duration": 5
          }
        },
        {
          "credits": 70,
          "when": {
            "text": "2.5 turbo pro",
            "duration": 10
          }
        },
        {
          "credits": 120,
          "when": {
            "text": "2.6 pro",
            "duration": 5
          }
        },
        {
          "credits": 180,
          "when": {
            "text": "2.6 pro",
            "duration": 5
          }
        }
      ],
      "min": 25,
      "max": 280
    },
    {
      "name": "Kling O1 First & Last Frame",
      "priceText": "5s - 56 10s - 112",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 56,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 112,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 56,
      "max": 112
    },
    {
      "name": "Kling 2.5 First & Last Frame",
      "priceText": "5s - 35 10s - 70",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 35,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 70,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 35,
      "max": 70
    },
    {
      "name": "Kling 2.1 First & Last Frame",
      "priceText": "5s - 45 10s - 90",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 45,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 90,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 45,
      "max": 90
    },
    {
      "name": "Luma Ray 2",
      "priceText": "5s - 108 9s - 194",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 108,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 194,
          "when": {
            "duration": 9
          }
        }
      ],
      "min": 108,
      "max": 194
    },
    {
      "name": "Luma Ray 2 Flash",
      "priceText": "5s - 36 9s - 65",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 36,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 65,
          "when": {
            "duration": 9
          }
        }
      ],
      "min": 36,
      "max": 65
    },
    {
      "name": "Minimax Video Director",
      "priceText": "60",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "MiniMax Video Director"
      ],
      "category": "video",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 60,
      "max": 60
    },
    {
      "name": "Minimax Video 01",
      "priceText": "60",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "MiniMax Video 01"
      ],
      "category": "video",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 60,
      "max": 60
    },
    {
      "name": "Hunyuan",
      "priceText": "60",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 60,
      "max": 60
    },
    {
      "name": "Skyreels",
      "priceText": "36",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "SkyReels"
      ],
      "category": "video",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 36,
      "max": 36
    },
    {
      "name": "Wan Video",
      "priceText": "24",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 24,
      "max": 24
    },
    {
      "name": "Higgsfield Video",
      "priceText": "Lite - 14 Turbo - 45 Preview - 62",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 14,
          "when": {
            "mode": "lite"
          }
        },
        {
          "credits": 45,
          "when": {
            "mode": "turbo"
          }
        },
        {
          "credits": 62,
          "when": {
            "mode": "preview"
          }
        }
      ],
      "min": 14,
      "max": 62
    },
    {
      "name": "Kling O1 Edit Video",
      "priceText": "147",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 147,
      "max": 147
    },
    {
      "name": "Kling O1 Reference Video to Video",
      "priceText": "5s -92 10s - 184",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 92,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 184,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 92,
      "max": 184
    },
    {
      "name": "Kling O3 Edit Video",
      "priceText": "Pro - 300 Standard - 400",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 300,
          "when": {
            "mode": "pro"
          }
        },
        {
          "credits": 400,
          "when": {
            "mode": "standard"
          }
        }
      ],
      "min": 300,
      "max": 400
    },
    {
      "name": "Kling Motion Control",
      "priceText": "Pro - 80 Standard - 50",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 80,
          "when": {
            "mode": "pro"
          }
        },
        {
          "credits": 50,
          "when": {
            "mode": "standard"
          }
        }
      ],
      "min": 50,
      "max": 80
    },
    {
      "name": "LTX 2 Video to Video",
      "priceText": "30",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 30,
      "max": 30
    },
    {
      "name": "Runway Aleph",
      "priceText": "66",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 66,
      "max": 66
    },
    {
      "name": "Runway Act-Two",
      "priceText": "5s -165 10s - 330",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Runway Act Two"
      ],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 165,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 330,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 165,
      "max": 330
    },
    {
      "name": "Luma Reframe",
      "priceText": "Fast - 320 Standard - 600",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 320,
          "when": {
            "mode": "fast"
          }
        },
        {
          "credits": 600,
          "when": {
            "mode": "standard"
          }
        }
      ],
      "min": 320,
      "max": 600
    },
    {
      "name": "Luma Modify",
      "priceText": "Fast - 320 Standard - 600",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 320,
          "when": {
            "mode": "fast"
          }
        },
        {
          "credits": 600,
          "when": {
            "mode": "standard"
          }
        }
      ],
      "min": 320,
      "max": 600
    },
    {
      "name": "Wan 2.2 Animate - Replace",
      "priceText": "480p - 48 580p- 72 720p - 100",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 48,
          "when": {
            "resolution": "480"
          }
        },
        {
          "credits": 72,
          "when": {
            "resolution": "580"
          }
        },
        {
          "credits": 100,
          "when": {
            "resolution": "720"
          }
        }
      ],
      "min": 48,
      "max": 100
    },
    {
      "name": "Wan 2.2 Animate - Move",
      "priceText": "480p - 48 580p- 72 720p - 100",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 48,
          "when": {
            "resolution": "480"
          }
        },
        {
          "credits": 72,
          "when": {
            "resolution": "580"
          }
        },
        {
          "credits": 100,
          "when": {
            "resolution": "720"
          }
        }
      ],
      "min": 48,
      "max": 100
    },
    {
      "name": "Wan Vace Depth",
      "priceText": "5s - 300 8s - 400",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Wan VACE Depth"
      ],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 300,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 400,
          "when": {
            "duration": 8
          }
        }
      ],
      "min": 300,
      "max": 400
    },
    {
      "name": "Wan Vace Pose",
      "priceText": "Lite 5s - 18 Lite 10s - 36 Pro 5s - 88 Pro 10s - 176",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Wan VACE Pose"
      ],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 18,
          "when": {
            "mode": "lite",
            "duration": 5
          }
        },
        {
          "credits": 36,
          "when": {
            "mode": "lite",
            "duration": 10
          }
        },
        {
          "credits": 88,
          "when": {
            "mode": "pro",
            "duration": 5
          }
        },
        {
          "credits": 176,
          "when": {
            "mode": "pro",
            "duration": 10
          }
        }
      ],
      "min": 18,
      "max": 176
    },
    {
      "name": "Wan Vace Reframe",
      "priceText": "5s - 60 10s - 90",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Wan VACE Reframe"
      ],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "dynamic",
      "options": [
        {
          "credits": 60,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 90,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 60,
      "max": 90
    },
    {
      "name": "Wan Vace Outpainting",
      "priceText": "120",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Wan VACE Outpainting"
      ],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 120,
      "max": 120
    },
    {
      "name": "Hunyuan Video to Video",
      "priceText": "60",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 60,
      "max": 60
    },
    {
      "name": "Flux Dev Redux",
      "priceText": "3",
      "source": "https://help.weavy.ai/en/articles/12344174-generate-from-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "image-to-image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 3,
      "max": 3
    },
    {
      "name": "Flux ControlNet & LoRA",
      "priceText": "10",
      "source": "https://help.weavy.ai/en/articles/12344174-generate-from-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Flux ControlNet LoRA"
      ],
      "category": "image-to-image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 10,
      "max": 10
    },
    {
      "name": "Flux Canny Pro",
      "priceText": "6",
      "source": "https://help.weavy.ai/en/articles/12344174-generate-from-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "image-to-image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 6,
      "max": 6
    },
    {
      "name": "Flux Depth Pro",
      "priceText": "6",
      "source": "https://help.weavy.ai/en/articles/12344174-generate-from-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "image-to-image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 6,
      "max": 6
    },
    {
      "name": "Qwen Edit Multiangle",
      "priceText": "4",
      "source": "https://help.weavy.ai/en/articles/12344174-generate-from-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Qwen Multiangle"
      ],
      "category": "image-to-image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 4,
      "max": 4
    },
    {
      "name": "Image to Image",
      "priceText": "10",
      "source": "https://help.weavy.ai/en/articles/12344174-generate-from-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "image-to-image"
      ],
      "category": "image-to-image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 10,
      "max": 10
    },
    {
      "name": "Stable Diffusion controlnets",
      "priceText": "1",
      "source": "https://help.weavy.ai/en/articles/12344174-generate-from-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Stable Diffusion ControlNet"
      ],
      "category": "image-to-image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 1,
      "max": 1
    },
    {
      "name": "Sketch To Image",
      "priceText": "0.1",
      "source": "https://help.weavy.ai/en/articles/12344174-generate-from-image-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Sketch-to-Image"
      ],
      "category": "image-to-image",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 0.1,
      "max": 0.1
    },
    {
      "name": "Bria Video Upscale",
      "priceText": "154",
      "source": "https://help.weavy.ai/en/articles/12344342-enhance-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-15",
      "aliases": [],
      "category": "enhance-video-",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 154,
      "max": 154
    },
    {
      "name": "Topaz Video Upscaler",
      "priceText": "12",
      "source": "https://help.weavy.ai/en/articles/12344342-enhance-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-15",
      "aliases": [],
      "category": "enhance-video-",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 12,
      "max": 12
    },
    {
      "name": "Real-ESRGAN Video Upscaler",
      "priceText": "71",
      "source": "https://help.weavy.ai/en/articles/12344342-enhance-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-15",
      "aliases": [],
      "category": "enhance-video-",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 71,
      "max": 71
    },
    {
      "name": "Video Smoother",
      "priceText": "5",
      "source": "https://help.weavy.ai/en/articles/12344342-enhance-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-15",
      "aliases": [],
      "category": "enhance-video-",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 5,
      "max": 5
    },
    {
      "name": "Topaz Upscale",
      "priceText": "19",
      "source": "https://help.weavy.ai/en/articles/12344205-enhance-images-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "enhance",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 19,
      "max": 19
    },
    {
      "name": "Topaz Sharpen",
      "priceText": "19",
      "source": "https://help.weavy.ai/en/articles/12344205-enhance-images-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "enhance",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 19,
      "max": 19
    },
    {
      "name": "Recraft Crisp Upscale",
      "priceText": "5",
      "source": "https://help.weavy.ai/en/articles/12344205-enhance-images-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "enhance",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 5,
      "max": 5
    },
    {
      "name": "Magnific Skin Enhancer",
      "priceText": "18",
      "source": "https://help.weavy.ai/en/articles/12344205-enhance-images-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "enhance",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 18,
      "max": 18
    },
    {
      "name": "Magnific Upscale",
      "priceText": "12",
      "source": "https://help.weavy.ai/en/articles/12344205-enhance-images-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "enhance",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 12,
      "max": 12
    },
    {
      "name": "Magnific Precision Upscale",
      "priceText": "18",
      "source": "https://help.weavy.ai/en/articles/12344205-enhance-images-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "enhance",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 18,
      "max": 18
    },
    {
      "name": "Magnific Precision Upscale V2",
      "priceText": "18",
      "source": "https://help.weavy.ai/en/articles/12344205-enhance-images-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "enhance",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 18,
      "max": 18
    },
    {
      "name": "Enhancor Image Upscale",
      "priceText": "36",
      "source": "https://help.weavy.ai/en/articles/12344205-enhance-images-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Enhancer Image Upscale"
      ],
      "category": "enhance",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 36,
      "max": 36
    },
    {
      "name": "Enhancor Realistic Skin",
      "priceText": "36",
      "source": "https://help.weavy.ai/en/articles/12344205-enhance-images-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Enhancer Realistic Skin"
      ],
      "category": "enhance",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 36,
      "max": 36
    },
    {
      "name": "Omnihuman V1.5",
      "priceText": "352",
      "source": "https://help.weavy.ai/en/articles/12441548-lip-sync-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "OmniHuman V1.5"
      ],
      "category": "lip-sync",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 352,
      "max": 352
    },
    {
      "name": "Sync 2 Pro",
      "priceText": "184",
      "source": "https://help.weavy.ai/en/articles/12441548-lip-sync-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "lip-sync",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 184,
      "max": 184
    },
    {
      "name": "Pixverse Lipsync",
      "priceText": "66",
      "source": "https://help.weavy.ai/en/articles/12441548-lip-sync-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "PixVerse Lip Sync"
      ],
      "category": "lip-sync",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 66,
      "max": 66
    },
    {
      "name": "Kling AI Avatar Pro",
      "priceText": "253",
      "source": "https://help.weavy.ai/en/articles/12441548-lip-sync-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "lip-sync",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 253,
      "max": 253
    },
    {
      "name": "Sam 3D Objects",
      "priceText": "3",
      "source": "https://help.weavy.ai/en/articles/12344357-3d-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "SAM 3D Objects"
      ],
      "category": "3d",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 3,
      "max": 3
    },
    {
      "name": "Rodin",
      "priceText": "48",
      "source": "https://help.weavy.ai/en/articles/12344357-3d-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "3d",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 48,
      "max": 48
    },
    {
      "name": "Rodin V2",
      "priceText": "36",
      "source": "https://help.weavy.ai/en/articles/12344357-3d-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "3d",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 36,
      "max": 36
    },
    {
      "name": "Trellis 3D V2",
      "priceText": "30",
      "source": "https://help.weavy.ai/en/articles/12344357-3d-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "3d",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 30,
      "max": 30
    },
    {
      "name": "Meshy V6",
      "priceText": "96",
      "source": "https://help.weavy.ai/en/articles/12344357-3d-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "3d",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 96,
      "max": 96
    },
    {
      "name": "Hunyuan 3D V3",
      "priceText": "80",
      "source": "https://help.weavy.ai/en/articles/12344357-3d-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "3d",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 80,
      "max": 80
    },
    {
      "name": "Hunyuan 3D",
      "priceText": "18",
      "source": "https://help.weavy.ai/en/articles/12344357-3d-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "3d",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 18,
      "max": 18
    },
    {
      "name": "Hunyuan 3D V2.1",
      "priceText": "25",
      "source": "https://help.weavy.ai/en/articles/12344357-3d-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "3d",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 25,
      "max": 25
    },
    {
      "name": "Trellis",
      "priceText": "2",
      "source": "https://help.weavy.ai/en/articles/12344357-3d-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "3d",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 2,
      "max": 2
    },
    {
      "name": "Vectorizer",
      "priceText": "24",
      "source": "https://help.weavy.ai/en/articles/12343888-vector-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "vector",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 24,
      "max": 24
    },
    {
      "name": "Recraft V3 SVG",
      "priceText": "10",
      "source": "https://help.weavy.ai/en/articles/12343888-vector-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "vector",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 10,
      "max": 10
    },
    {
      "name": "Text To Vector",
      "priceText": "6",
      "source": "https://help.weavy.ai/en/articles/12343888-vector-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Text-to-Vector"
      ],
      "category": "vector",
      "provenance": "official-help",
      "kind": "fixed",
      "min": 6,
      "max": 6
    },
    {
      "name": "Beeble SwitchX",
      "aliases": [
        "Beeble SwitchX",
        "Beeble Switch X",
        "beeble_switchx",
        "beeble-switchx",
        "beeble/switchx",
        "switchx"
      ],
      "category": "video-edit",
      "kind": "formula",
      "formulas": [
        {
          "perSecond": 60,
          "secondsRounding": "ceil",
          "when": {
            "resolution": "1080"
          }
        }
      ],
      "min": null,
      "max": null,
      "parameterLabel": "разрешение и длительность",
      "missingParameterReason": "Для SwitchX нужны сохранённые разрешение и длительность. Для неизвестной комбинации расширение не переносит цену с текущих настроек на старый запуск.",
      "provenance": "reference-only",
      "source": "Предоставленный каталог 0.20.0",
      "publishedAt": "2026-07-28",
      "checkedAt": null,
      "priceText": "Формула из предыдущего каталога"
    },
    {
      "name": "Kling 2.1 Standard",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-10-23",
      "publishedAt": "2026-04-26",
      "derivedFrom": "Kling Video",
      "modelVariant": "2.1 standard",
      "kind": "dynamic",
      "options": [
        {
          "credits": 25,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 50,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 25,
      "max": 50,
      "priceText": "5s — 25 / 10s — 50"
    },
    {
      "name": "Kling 2.1 Pro",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-10-23",
      "publishedAt": "2026-04-26",
      "derivedFrom": "Kling Video",
      "modelVariant": "2.1 pro",
      "kind": "dynamic",
      "options": [
        {
          "credits": 45,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 90,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 45,
      "max": 90,
      "priceText": "5s — 45 / 10s — 90"
    },
    {
      "name": "Kling 2.1 Master",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-10-23",
      "publishedAt": "2026-04-26",
      "derivedFrom": "Kling Video",
      "modelVariant": "2.1 master",
      "kind": "dynamic",
      "options": [
        {
          "credits": 90,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 280,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 90,
      "max": 280,
      "priceText": "5s — 90 / 10s — 280"
    },
    {
      "name": "Kling 2.5 Turbo Pro",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-10-23",
      "publishedAt": "2026-04-26",
      "derivedFrom": "Kling Video",
      "modelVariant": "2.5 turbo pro",
      "kind": "dynamic",
      "options": [
        {
          "credits": 35,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 70,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 35,
      "max": 70,
      "priceText": "5s — 35 / 10s — 70"
    },
    {
      "name": "Kling 2.6 Pro",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-10-23",
      "publishedAt": "2026-04-26",
      "derivedFrom": "Kling Video",
      "modelVariant": "2.6 pro",
      "kind": "dynamic",
      "options": [
        {
          "credits": 120,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 180,
          "when": {
            "duration": 5
          }
        }
      ],
      "min": 120,
      "max": 180,
      "priceText": "5s — 120 / 5s — 180",
      "pricedDurations": [
        5
      ],
      "pricingWarning": "В источнике две разные цены для Kling 2.6 Pro за 5 секунд; точный тариф не подтверждён"
    },
    {
      "name": "Seedance 2.0 Fast",
      "priceText": "Fast · 116 / 443; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 116,
          "when": {
            "duration": 4
          }
        },
        {
          "credits": 443,
          "when": {
            "duration": 15
          }
        }
      ],
      "min": 116,
      "max": 443,
      "parameterLabel": "Параметры варианта Fast",
      "unsupportedResolutions": [
        "1080",
        "1080p"
      ],
      "derivedFrom": "Seedance 2.0",
      "modelMode": "fast"
    },
    {
      "name": "Seedance 2.0 Standard",
      "priceText": "Standard · 145 / 552; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 145,
          "when": {
            "duration": 4
          }
        },
        {
          "credits": 552,
          "when": {
            "duration": 15
          }
        }
      ],
      "min": 145,
      "max": 552,
      "parameterLabel": "Параметры варианта Standard",
      "unsupportedResolutions": [
        "1080",
        "1080p"
      ],
      "derivedFrom": "Seedance 2.0",
      "modelMode": "standard"
    },
    {
      "name": "Seedance 2.0 Reference Fast",
      "priceText": "Fast · 116 / 443; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Seedance 2.0 Fast Reference"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 116,
          "when": {
            "duration": 4
          }
        },
        {
          "credits": 443,
          "when": {
            "duration": 15
          }
        }
      ],
      "min": 116,
      "max": 443,
      "parameterLabel": "Параметры варианта Fast",
      "unsupportedResolutions": [
        "1080",
        "1080p"
      ],
      "derivedFrom": "Seedance 2.0 Reference",
      "modelMode": "fast"
    },
    {
      "name": "Seedance 2.0 Reference Standard",
      "priceText": "Standard · 145 / 552; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Seedance 2.0 Standard Reference"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 145,
          "when": {
            "duration": 4
          }
        },
        {
          "credits": 552,
          "when": {
            "duration": 15
          }
        }
      ],
      "min": 145,
      "max": 552,
      "parameterLabel": "Параметры варианта Standard",
      "unsupportedResolutions": [
        "1080",
        "1080p"
      ],
      "derivedFrom": "Seedance 2.0 Reference",
      "modelMode": "standard"
    },
    {
      "name": "Kling 3 Pro",
      "priceText": "Pro · 80 / 440; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 80,
          "when": {
            "duration": 3
          }
        },
        {
          "credits": 440,
          "when": {
            "duration": 15
          }
        }
      ],
      "min": 80,
      "max": 440,
      "parameterLabel": "Параметры варианта Pro",
      "derivedFrom": "Kling 3",
      "modelMode": "pro"
    },
    {
      "name": "Kling 3 Standard",
      "priceText": "Standard · 60 / 300; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 60,
          "when": {
            "duration": 3
          }
        },
        {
          "credits": 300,
          "when": {
            "duration": 15
          }
        }
      ],
      "min": 60,
      "max": 300,
      "parameterLabel": "Параметры варианта Standard",
      "derivedFrom": "Kling 3",
      "modelMode": "standard"
    },
    {
      "name": "Sora 2 Normal",
      "priceText": "Normal · 96; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 96,
          "when": {}
        }
      ],
      "min": 96,
      "max": 96,
      "parameterLabel": "Параметры варианта Normal",
      "derivedFrom": "Sora 2",
      "modelMode": "normal"
    },
    {
      "name": "Sora 2 Pro",
      "priceText": "Pro · 288; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 288,
          "when": {}
        }
      ],
      "min": 288,
      "max": 288,
      "parameterLabel": "Параметры варианта Pro",
      "derivedFrom": "Sora 2",
      "modelMode": "pro"
    },
    {
      "name": "LTX 2 Video Fast",
      "priceText": "Fast · 50 / 100 / 200; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "LTX 2 Fast Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 50,
          "when": {
            "duration": 6
          }
        },
        {
          "credits": 100,
          "when": {
            "duration": 8
          }
        },
        {
          "credits": 200,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 50,
      "max": 200,
      "parameterLabel": "Параметры варианта Fast",
      "derivedFrom": "LTX 2 Video",
      "modelMode": "fast"
    },
    {
      "name": "LTX 2 Video Pro",
      "priceText": "Pro · 70 / 140 / 280; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "LTX 2 Pro Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 70,
          "when": {
            "duration": 6
          }
        },
        {
          "credits": 140,
          "when": {
            "duration": 8
          }
        },
        {
          "credits": 280,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 70,
      "max": 280,
      "parameterLabel": "Параметры варианта Pro",
      "derivedFrom": "LTX 2 Video",
      "modelMode": "pro"
    },
    {
      "name": "Veo 3.1 Text to Image Fast",
      "priceText": "Fast · 120; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Veo 3.1 Fast Text to Image",
        "Veo 3.1 Text to Video Fast",
        "Veo 3.1 Fast Text to Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 120,
          "when": {}
        }
      ],
      "min": 120,
      "max": 120,
      "parameterLabel": "Параметры варианта Fast",
      "derivedFrom": "Veo 3.1 Text to Image",
      "modelMode": "fast"
    },
    {
      "name": "Veo 3.1 Text to Image Standard",
      "priceText": "Standard · 320; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Veo 3.1 Standard Text to Image",
        "Veo 3.1 Text to Video Standard",
        "Veo 3.1 Standard Text to Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 320,
          "when": {}
        }
      ],
      "min": 320,
      "max": 320,
      "parameterLabel": "Параметры варианта Standard",
      "derivedFrom": "Veo 3.1 Text to Image",
      "modelMode": "standard"
    },
    {
      "name": "Veo 3.1 Image to Video Fast",
      "priceText": "Fast · 120; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Veo 3.1 Fast Image to Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 120,
          "when": {}
        }
      ],
      "min": 120,
      "max": 120,
      "parameterLabel": "Параметры варианта Fast",
      "derivedFrom": "Veo 3.1 Image to Video",
      "modelMode": "fast"
    },
    {
      "name": "Veo 3.1 Image to Video Standard",
      "priceText": "Standard · 320; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Veo 3.1 Standard Image to Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 320,
          "when": {}
        }
      ],
      "min": 320,
      "max": 320,
      "parameterLabel": "Параметры варианта Standard",
      "derivedFrom": "Veo 3.1 Image to Video",
      "modelMode": "standard"
    },
    {
      "name": "Veo 3 Text to Image Fast",
      "priceText": "Fast · 120; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Veo 3 Fast Text to Image",
        "Veo 3 Text to Video Fast",
        "Veo 3 Fast Text to Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 120,
          "when": {}
        }
      ],
      "min": 120,
      "max": 120,
      "parameterLabel": "Параметры варианта Fast",
      "derivedFrom": "Veo 3 Text to Image",
      "modelMode": "fast"
    },
    {
      "name": "Veo 3 Text to Image Standard",
      "priceText": "Standard · 320; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Veo 3 Standard Text to Image",
        "Veo 3 Text to Video Standard",
        "Veo 3 Standard Text to Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 320,
          "when": {}
        }
      ],
      "min": 320,
      "max": 320,
      "parameterLabel": "Параметры варианта Standard",
      "derivedFrom": "Veo 3 Text to Image",
      "modelMode": "standard"
    },
    {
      "name": "Veo 3 Image to Video Fast",
      "priceText": "Fast · 120; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Veo 3 Fast Image to Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 120,
          "when": {}
        }
      ],
      "min": 120,
      "max": 120,
      "parameterLabel": "Параметры варианта Fast",
      "derivedFrom": "Veo 3 Image to Video",
      "modelMode": "fast"
    },
    {
      "name": "Veo 3 Image to Video Standard",
      "priceText": "Standard · 320; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Veo 3 Standard Image to Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 320,
          "when": {}
        }
      ],
      "min": 320,
      "max": 320,
      "parameterLabel": "Параметры варианта Standard",
      "derivedFrom": "Veo 3 Image to Video",
      "modelMode": "standard"
    },
    {
      "name": "Seedance V1.0 Lite",
      "priceText": "Lite · 18 / 36; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Seedance 1.0 Lite"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 18,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 36,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 18,
      "max": 36,
      "parameterLabel": "Параметры варианта Lite",
      "derivedFrom": "Seedance V1.0",
      "modelMode": "lite"
    },
    {
      "name": "Seedance V1.0 Pro",
      "priceText": "Pro · 88 / 176; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Seedance 1.0 Pro"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 88,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 176,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 88,
      "max": 176,
      "parameterLabel": "Параметры варианта Pro",
      "derivedFrom": "Seedance V1.0",
      "modelMode": "pro"
    },
    {
      "name": "Kling 1.6 Standard",
      "priceText": "Standard · 18 / 36; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 18,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 36,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 18,
      "max": 36,
      "parameterLabel": "Параметры варианта Standard",
      "derivedFrom": "Kling 1.6",
      "modelMode": "standard"
    },
    {
      "name": "Kling 1.6 Pro",
      "priceText": "Pro · 37.5 / 75; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 37.5,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 75,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 37.5,
      "max": 75,
      "parameterLabel": "Параметры варианта Pro",
      "derivedFrom": "Kling 1.6",
      "modelMode": "pro"
    },
    {
      "name": "Higgsfield Video Lite",
      "priceText": "Lite · 14; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Higgsfield Lite Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 14,
          "when": {}
        }
      ],
      "min": 14,
      "max": 14,
      "parameterLabel": "Параметры варианта Lite",
      "derivedFrom": "Higgsfield Video",
      "modelMode": "lite"
    },
    {
      "name": "Higgsfield Video Turbo",
      "priceText": "Turbo · 45; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Higgsfield Turbo Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 45,
          "when": {}
        }
      ],
      "min": 45,
      "max": 45,
      "parameterLabel": "Параметры варианта Turbo",
      "derivedFrom": "Higgsfield Video",
      "modelMode": "turbo"
    },
    {
      "name": "Higgsfield Video Preview",
      "priceText": "Preview · 62; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344226-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-04-26",
      "aliases": [
        "Higgsfield Preview Video"
      ],
      "category": "video",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 62,
          "when": {}
        }
      ],
      "min": 62,
      "max": 62,
      "parameterLabel": "Параметры варианта Preview",
      "derivedFrom": "Higgsfield Video",
      "modelMode": "preview"
    },
    {
      "name": "Kling O3 Edit Video Pro",
      "priceText": "Pro · 300; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Kling O3 Pro Edit Video"
      ],
      "category": "video-edit",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 300,
          "when": {}
        }
      ],
      "min": 300,
      "max": 300,
      "parameterLabel": "Параметры варианта Pro",
      "derivedFrom": "Kling O3 Edit Video",
      "modelMode": "pro"
    },
    {
      "name": "Kling O3 Edit Video Standard",
      "priceText": "Standard · 400; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Kling O3 Standard Edit Video"
      ],
      "category": "video-edit",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 400,
          "when": {}
        }
      ],
      "min": 400,
      "max": 400,
      "parameterLabel": "Параметры варианта Standard",
      "derivedFrom": "Kling O3 Edit Video",
      "modelMode": "standard"
    },
    {
      "name": "Kling Motion Control Pro",
      "priceText": "Pro · 80; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 80,
          "when": {}
        }
      ],
      "min": 80,
      "max": 80,
      "parameterLabel": "Параметры варианта Pro",
      "derivedFrom": "Kling Motion Control",
      "modelMode": "pro"
    },
    {
      "name": "Kling Motion Control Standard",
      "priceText": "Standard · 50; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 50,
          "when": {}
        }
      ],
      "min": 50,
      "max": 50,
      "parameterLabel": "Параметры варианта Standard",
      "derivedFrom": "Kling Motion Control",
      "modelMode": "standard"
    },
    {
      "name": "Luma Reframe Fast",
      "priceText": "Fast · 320; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 320,
          "when": {}
        }
      ],
      "min": 320,
      "max": 320,
      "parameterLabel": "Параметры варианта Fast",
      "derivedFrom": "Luma Reframe",
      "modelMode": "fast"
    },
    {
      "name": "Luma Reframe Standard",
      "priceText": "Standard · 600; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 600,
          "when": {}
        }
      ],
      "min": 600,
      "max": 600,
      "parameterLabel": "Параметры варианта Standard",
      "derivedFrom": "Luma Reframe",
      "modelMode": "standard"
    },
    {
      "name": "Luma Modify Fast",
      "priceText": "Fast · 320; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 320,
          "when": {}
        }
      ],
      "min": 320,
      "max": 320,
      "parameterLabel": "Параметры варианта Fast",
      "derivedFrom": "Luma Modify",
      "modelMode": "fast"
    },
    {
      "name": "Luma Modify Standard",
      "priceText": "Standard · 600; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [],
      "category": "video-edit",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 600,
          "when": {}
        }
      ],
      "min": 600,
      "max": 600,
      "parameterLabel": "Параметры варианта Standard",
      "derivedFrom": "Luma Modify",
      "modelMode": "standard"
    },
    {
      "name": "Wan Vace Pose Lite",
      "priceText": "Lite · 18 / 36; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Wan VACE Pose Lite"
      ],
      "category": "video-edit",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 18,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 36,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 18,
      "max": 36,
      "parameterLabel": "Параметры варианта Lite",
      "derivedFrom": "Wan Vace Pose",
      "modelMode": "lite"
    },
    {
      "name": "Wan Vace Pose Pro",
      "priceText": "Pro · 88 / 176; остальные условия из исходной таблицы",
      "source": "https://help.weavy.ai/en/articles/12344285-generate-from-video-models-comparison",
      "checkedAt": "2026-09-22",
      "publishedAt": "2026-03-29",
      "aliases": [
        "Wan VACE Pose Pro"
      ],
      "category": "video-edit",
      "provenance": "official-help-variant",
      "kind": "dynamic",
      "options": [
        {
          "credits": 88,
          "when": {
            "duration": 5
          }
        },
        {
          "credits": 176,
          "when": {
            "duration": 10
          }
        }
      ],
      "min": 88,
      "max": 176,
      "parameterLabel": "Параметры варианта Pro",
      "derivedFrom": "Wan Vace Pose",
      "modelMode": "pro"
    },
    {
      "name": "AionLabs: Aion-2.0",
      "aliases": [
        "aion-labs/aion-2.0",
        "Aion-2.0",
        "aion-2.0"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "aion-labs/aion-2.0"
    },
    {
      "name": "AionLabs: Aion-3.0",
      "aliases": [
        "aion-labs/aion-3.0",
        "Aion-3.0",
        "aion-3.0"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "aion-labs/aion-3.0"
    },
    {
      "name": "AionLabs: Aion-3.0-Mini",
      "aliases": [
        "aion-labs/aion-3.0-mini",
        "Aion-3.0-Mini",
        "aion-3.0-mini"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "aion-labs/aion-3.0-mini"
    },
    {
      "name": "AionLabs: Aion 3.5",
      "aliases": [
        "aion-labs/aion-3.5",
        "Aion 3.5",
        "aion-3.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "aion-labs/aion-3.5"
    },
    {
      "name": "AionLabs: Aion 3.5 Mini",
      "aliases": [
        "aion-labs/aion-3.5-mini",
        "Aion 3.5 Mini",
        "aion-3.5-mini"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "aion-labs/aion-3.5-mini"
    },
    {
      "name": "AionLabs: Aion-RP 1.0 (8B)",
      "aliases": [
        "aion-labs/aion-rp-llama-3.1-8b",
        "Aion-RP 1.0 (8B)",
        "aion-rp-llama-3.1-8b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "aion-labs/aion-rp-llama-3.1-8b"
    },
    {
      "name": "Amazon: Nova 2 Lite",
      "aliases": [
        "amazon/nova-2-lite-v1",
        "Nova 2 Lite",
        "nova-2-lite-v1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "amazon/nova-2-lite-v1"
    },
    {
      "name": "Amazon: Nova Lite 1.0",
      "aliases": [
        "amazon/nova-lite-v1",
        "Nova Lite 1.0",
        "nova-lite-v1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "amazon/nova-lite-v1"
    },
    {
      "name": "Amazon: Nova Micro 1.0",
      "aliases": [
        "amazon/nova-micro-v1",
        "Nova Micro 1.0",
        "nova-micro-v1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "amazon/nova-micro-v1"
    },
    {
      "name": "Amazon: Nova Premier 1.0",
      "aliases": [
        "amazon/nova-premier-v1",
        "Nova Premier 1.0",
        "nova-premier-v1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "amazon/nova-premier-v1"
    },
    {
      "name": "Amazon: Nova Pro 1.0",
      "aliases": [
        "amazon/nova-pro-v1",
        "Nova Pro 1.0",
        "nova-pro-v1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "amazon/nova-pro-v1"
    },
    {
      "name": "Magnum v4 72B",
      "aliases": [
        "anthracite-org/magnum-v4-72b",
        "Magnum v4 72B",
        "magnum-v4-72b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthracite-org/magnum-v4-72b"
    },
    {
      "name": "Anthropic: Claude Fable 5",
      "aliases": [
        "anthropic/claude-fable-5",
        "Claude Fable 5",
        "claude-fable-5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-fable-5"
    },
    {
      "name": "Anthropic: Claude Fable 5.1",
      "aliases": [
        "anthropic/claude-fable-5.1",
        "Claude Fable 5.1",
        "claude-fable-5.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-fable-5.1"
    },
    {
      "name": "Anthropic: Claude Haiku 4.5",
      "aliases": [
        "anthropic/claude-haiku-4.5",
        "Claude Haiku 4.5",
        "claude-haiku-4.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-haiku-4.5"
    },
    {
      "name": "Anthropic: Claude Haiku 5.5",
      "aliases": [
        "anthropic/claude-haiku-5.5",
        "Claude Haiku 5.5",
        "claude-haiku-5.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-haiku-5.5"
    },
    {
      "name": "Anthropic: Claude Opus 4.1",
      "aliases": [
        "anthropic/claude-opus-4.1",
        "Claude Opus 4.1",
        "claude-opus-4.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-opus-4.1"
    },
    {
      "name": "Anthropic: Claude Opus 4.5",
      "aliases": [
        "anthropic/claude-opus-4.5",
        "Claude Opus 4.5",
        "claude-opus-4.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-opus-4.5"
    },
    {
      "name": "Anthropic: Claude Opus 4.6",
      "aliases": [
        "anthropic/claude-opus-4.6",
        "Claude Opus 4.6",
        "claude-opus-4.6"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-opus-4.6"
    },
    {
      "name": "Anthropic: Claude Opus 4.7",
      "aliases": [
        "anthropic/claude-opus-4.7",
        "Claude Opus 4.7",
        "claude-opus-4.7"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-opus-4.7"
    },
    {
      "name": "Anthropic: Claude Opus 4.8",
      "aliases": [
        "anthropic/claude-opus-4.8",
        "Claude Opus 4.8",
        "claude-opus-4.8"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-opus-4.8"
    },
    {
      "name": "Anthropic: Claude Opus 5",
      "aliases": [
        "anthropic/claude-opus-5",
        "Claude Opus 5",
        "claude-opus-5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-opus-5"
    },
    {
      "name": "Anthropic: Claude Opus 5.5",
      "aliases": [
        "anthropic/claude-opus-5.5",
        "Claude Opus 5.5",
        "claude-opus-5.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-opus-5.5"
    },
    {
      "name": "Anthropic: Claude Sonnet 4.5",
      "aliases": [
        "anthropic/claude-sonnet-4.5",
        "Claude Sonnet 4.5",
        "claude-sonnet-4.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-sonnet-4.5"
    },
    {
      "name": "Anthropic: Claude Sonnet 4.6",
      "aliases": [
        "anthropic/claude-sonnet-4.6",
        "Claude Sonnet 4.6",
        "claude-sonnet-4.6"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-sonnet-4.6"
    },
    {
      "name": "Anthropic: Claude Sonnet 5",
      "aliases": [
        "anthropic/claude-sonnet-5",
        "Claude Sonnet 5",
        "claude-sonnet-5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-sonnet-5"
    },
    {
      "name": "Anthropic: Claude Sonnet 5.5",
      "aliases": [
        "anthropic/claude-sonnet-5.5",
        "Claude Sonnet 5.5",
        "claude-sonnet-5.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "anthropic/claude-sonnet-5.5"
    },
    {
      "name": "ByteDance Seed: Seed 1.6",
      "aliases": [
        "bytedance-seed/seed-1.6",
        "Seed 1.6",
        "seed-1.6"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "bytedance-seed/seed-1.6"
    },
    {
      "name": "ByteDance Seed: Seed 1.6 Flash",
      "aliases": [
        "bytedance-seed/seed-1.6-flash",
        "Seed 1.6 Flash",
        "seed-1.6-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "bytedance-seed/seed-1.6-flash"
    },
    {
      "name": "ByteDance Seed: Seed 2.1 Turbo",
      "aliases": [
        "bytedance-seed/seed-2-1-turbo",
        "Seed 2.1 Turbo",
        "seed-2-1-turbo"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "bytedance-seed/seed-2-1-turbo"
    },
    {
      "name": "ByteDance Seed: Seed-2.0-Code",
      "aliases": [
        "bytedance-seed/seed-2.0-code",
        "Seed-2.0-Code",
        "seed-2.0-code"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "bytedance-seed/seed-2.0-code"
    },
    {
      "name": "ByteDance Seed: Seed-2.0-Lite",
      "aliases": [
        "bytedance-seed/seed-2.0-lite",
        "Seed-2.0-Lite",
        "seed-2.0-lite"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "bytedance-seed/seed-2.0-lite"
    },
    {
      "name": "ByteDance Seed: Seed-2.0-Mini",
      "aliases": [
        "bytedance-seed/seed-2.0-mini",
        "Seed-2.0-Mini",
        "seed-2.0-mini"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "bytedance-seed/seed-2.0-mini"
    },
    {
      "name": "ByteDance: UI-TARS 7B ",
      "aliases": [
        "bytedance/ui-tars-1.5-7b",
        "UI-TARS 7B ",
        "ui-tars-1.5-7b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "bytedance/ui-tars-1.5-7b"
    },
    {
      "name": "Venice: Uncensored",
      "aliases": [
        "cognitivecomputations/dolphin-mistral-24b-venice-edition",
        "Uncensored",
        "dolphin-mistral-24b-venice-edition"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "cognitivecomputations/dolphin-mistral-24b-venice-edition"
    },
    {
      "name": "Cohere: Command A",
      "aliases": [
        "cohere/command-a",
        "Command A",
        "command-a"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "cohere/command-a"
    },
    {
      "name": "Cohere: Command A+",
      "aliases": [
        "cohere/command-a-plus",
        "Command A+",
        "command-a-plus"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "cohere/command-a-plus"
    },
    {
      "name": "Cohere: Command R (08-2024)",
      "aliases": [
        "cohere/command-r-08-2024",
        "Command R (08-2024)",
        "command-r-08-2024"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "cohere/command-r-08-2024"
    },
    {
      "name": "Cohere: Command R+ (08-2024)",
      "aliases": [
        "cohere/command-r-plus-08-2024",
        "Command R+ (08-2024)",
        "command-r-plus-08-2024"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "cohere/command-r-plus-08-2024"
    },
    {
      "name": "Cohere: Command R7B (12-2024)",
      "aliases": [
        "cohere/command-r7b-12-2024",
        "Command R7B (12-2024)",
        "command-r7b-12-2024"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "cohere/command-r7b-12-2024"
    },
    {
      "name": "DeepSeek: DeepSeek V3",
      "aliases": [
        "deepseek/deepseek-chat",
        "DeepSeek V3",
        "deepseek-chat"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-chat"
    },
    {
      "name": "DeepSeek: DeepSeek V3 0324",
      "aliases": [
        "deepseek/deepseek-chat-v3-0324",
        "DeepSeek V3 0324",
        "deepseek-chat-v3-0324"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-chat-v3-0324"
    },
    {
      "name": "DeepSeek: DeepSeek V3.1",
      "aliases": [
        "deepseek/deepseek-chat-v3.1",
        "DeepSeek V3.1",
        "deepseek-chat-v3.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-chat-v3.1"
    },
    {
      "name": "DeepSeek: R1 0528",
      "aliases": [
        "deepseek/deepseek-r1-0528",
        "R1 0528",
        "deepseek-r1-0528"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-r1-0528"
    },
    {
      "name": "DeepSeek: DeepSeek V3.1 Terminus",
      "aliases": [
        "deepseek/deepseek-v3.1-terminus",
        "DeepSeek V3.1 Terminus",
        "deepseek-v3.1-terminus"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-v3.1-terminus"
    },
    {
      "name": "DeepSeek: DeepSeek V3.2",
      "aliases": [
        "deepseek/deepseek-v3.2",
        "DeepSeek V3.2",
        "deepseek-v3.2"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-v3.2"
    },
    {
      "name": "DeepSeek: DeepSeek V3.2 Exp",
      "aliases": [
        "deepseek/deepseek-v3.2-exp",
        "DeepSeek V3.2 Exp",
        "deepseek-v3.2-exp"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-v3.2-exp"
    },
    {
      "name": "DeepSeek: DeepSeek V4 Flash 0423",
      "aliases": [
        "deepseek/deepseek-v4-flash",
        "DeepSeek V4 Flash 0423",
        "deepseek-v4-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-v4-flash"
    },
    {
      "name": "DeepSeek: DeepSeek V4 Flash 0731",
      "aliases": [
        "deepseek/deepseek-v4-flash-0731",
        "DeepSeek V4 Flash 0731",
        "deepseek-v4-flash-0731"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-v4-flash-0731"
    },
    {
      "name": "DeepSeek: DeepSeek V4 Flash Vision Exp",
      "aliases": [
        "deepseek/deepseek-v4-flash-vision-exp",
        "DeepSeek V4 Flash Vision Exp",
        "deepseek-v4-flash-vision-exp"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-v4-flash-vision-exp"
    },
    {
      "name": "DeepSeek: DeepSeek V4 Pro 0423",
      "aliases": [
        "deepseek/deepseek-v4-pro",
        "DeepSeek V4 Pro 0423",
        "deepseek-v4-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-v4-pro"
    },
    {
      "name": "DeepSeek: DeepSeek V4 Pro 0813",
      "aliases": [
        "deepseek/deepseek-v4-pro-0813",
        "DeepSeek V4 Pro 0813",
        "deepseek-v4-pro-0813"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-v4-pro-0813"
    },
    {
      "name": "DeepSeek: DeepSeek V4.1 Flash",
      "aliases": [
        "deepseek/deepseek-v4.1-flash",
        "DeepSeek V4.1 Flash",
        "deepseek-v4.1-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-v4.1-flash"
    },
    {
      "name": "DeepSeek: DeepSeek V4.1 Flash 1017",
      "aliases": [
        "deepseek/deepseek-v4.1-flash-1017",
        "DeepSeek V4.1 Flash 1017",
        "deepseek-v4.1-flash-1017"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "deepseek/deepseek-v4.1-flash-1017"
    },
    {
      "name": "Elorian: Glimpse",
      "aliases": [
        "elorian/glimpse",
        "Glimpse",
        "glimpse"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "elorian/glimpse"
    },
    {
      "name": "Fireworks: Ember-1",
      "aliases": [
        "fireworks/ember-1",
        "Ember-1",
        "ember-1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "fireworks/ember-1"
    },
    {
      "name": "Google: Gemini 2.5 Flash",
      "aliases": [
        "google/gemini-2.5-flash",
        "Gemini 2.5 Flash",
        "gemini-2.5-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-2.5-flash"
    },
    {
      "name": "Google: Gemini 2.5 Flash Lite",
      "aliases": [
        "google/gemini-2.5-flash-lite",
        "Gemini 2.5 Flash Lite",
        "gemini-2.5-flash-lite"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-2.5-flash-lite"
    },
    {
      "name": "Google: Gemini 2.5 Pro",
      "aliases": [
        "google/gemini-2.5-pro",
        "Gemini 2.5 Pro",
        "gemini-2.5-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-2.5-pro"
    },
    {
      "name": "Google: Gemini 2.5 Pro Preview 06-05",
      "aliases": [
        "google/gemini-2.5-pro-preview",
        "Gemini 2.5 Pro Preview 06-05",
        "gemini-2.5-pro-preview"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-2.5-pro-preview"
    },
    {
      "name": "Google: Gemini 3 Flash Preview",
      "aliases": [
        "google/gemini-3-flash-preview",
        "Gemini 3 Flash Preview",
        "gemini-3-flash-preview"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-3-flash-preview"
    },
    {
      "name": "Google: Gemini 3.1 Flash Lite",
      "aliases": [
        "google/gemini-3.1-flash-lite",
        "Gemini 3.1 Flash Lite",
        "gemini-3.1-flash-lite"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-3.1-flash-lite"
    },
    {
      "name": "Google: Gemini 3.1 Flash Lite Preview",
      "aliases": [
        "google/gemini-3.1-flash-lite-preview",
        "Gemini 3.1 Flash Lite Preview",
        "gemini-3.1-flash-lite-preview"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-3.1-flash-lite-preview"
    },
    {
      "name": "Google: Gemini 3.1 Pro Preview",
      "aliases": [
        "google/gemini-3.1-pro-preview",
        "Gemini 3.1 Pro Preview",
        "gemini-3.1-pro-preview"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-3.1-pro-preview"
    },
    {
      "name": "Google: Gemini 3.1 Pro Preview Custom Tools",
      "aliases": [
        "google/gemini-3.1-pro-preview-customtools",
        "Gemini 3.1 Pro Preview Custom Tools",
        "gemini-3.1-pro-preview-customtools"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-3.1-pro-preview-customtools"
    },
    {
      "name": "Google: Gemini 3.5 Flash",
      "aliases": [
        "google/gemini-3.5-flash",
        "Gemini 3.5 Flash",
        "gemini-3.5-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-3.5-flash"
    },
    {
      "name": "Google: Gemini 3.5 Flash Lite",
      "aliases": [
        "google/gemini-3.5-flash-lite",
        "Gemini 3.5 Flash Lite",
        "gemini-3.5-flash-lite"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-3.5-flash-lite"
    },
    {
      "name": "Google: Gemini 3.6 Flash",
      "aliases": [
        "google/gemini-3.6-flash",
        "Gemini 3.6 Flash",
        "gemini-3.6-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-3.6-flash"
    },
    {
      "name": "Google: Gemini 3.7 Flash",
      "aliases": [
        "google/gemini-3.7-flash",
        "Gemini 3.7 Flash",
        "gemini-3.7-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-3.7-flash"
    },
    {
      "name": "Google: Gemini 3.8 Flash",
      "aliases": [
        "google/gemini-3.8-flash",
        "Gemini 3.8 Flash",
        "gemini-3.8-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-3.8-flash"
    },
    {
      "name": "Google: Gemini 4 Argon",
      "aliases": [
        "google/gemini-4-argon",
        "Gemini 4 Argon",
        "gemini-4-argon"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemini-4-argon"
    },
    {
      "name": "Google: Gemma 2 27B",
      "aliases": [
        "google/gemma-2-27b-it",
        "Gemma 2 27B",
        "gemma-2-27b-it"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemma-2-27b-it"
    },
    {
      "name": "Google: Gemma 3 12B",
      "aliases": [
        "google/gemma-3-12b-it",
        "Gemma 3 12B",
        "gemma-3-12b-it"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemma-3-12b-it"
    },
    {
      "name": "Google: Gemma 3 27B",
      "aliases": [
        "google/gemma-3-27b-it",
        "Gemma 3 27B",
        "gemma-3-27b-it"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemma-3-27b-it"
    },
    {
      "name": "Google: Gemma 3 4B",
      "aliases": [
        "google/gemma-3-4b-it",
        "Gemma 3 4B",
        "gemma-3-4b-it"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemma-3-4b-it"
    },
    {
      "name": "Google: Gemma 4 26B A4B ",
      "aliases": [
        "google/gemma-4-26b-a4b-it",
        "Gemma 4 26B A4B ",
        "gemma-4-26b-a4b-it"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemma-4-26b-a4b-it"
    },
    {
      "name": "Google: Gemma 4 31B",
      "aliases": [
        "google/gemma-4-31b-it",
        "Gemma 4 31B",
        "gemma-4-31b-it"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "google/gemma-4-31b-it"
    },
    {
      "name": "MythoMax 13B",
      "aliases": [
        "gryphe/mythomax-l2-13b",
        "MythoMax 13B",
        "mythomax-l2-13b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "gryphe/mythomax-l2-13b"
    },
    {
      "name": "IBM: Granite 4.2 8B",
      "aliases": [
        "ibm-granite/granite-4.2-8b",
        "Granite 4.2 8B",
        "granite-4.2-8b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "ibm-granite/granite-4.2-8b"
    },
    {
      "name": "Inception: Mercury 2",
      "aliases": [
        "inception/mercury-2",
        "Mercury 2",
        "mercury-2"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "inception/mercury-2"
    },
    {
      "name": "Inception: Mercury 2.5",
      "aliases": [
        "inception/mercury-2.5",
        "Mercury 2.5",
        "mercury-2.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "inception/mercury-2.5"
    },
    {
      "name": "Inception: Mercury 3",
      "aliases": [
        "inception/mercury-3",
        "Mercury 3",
        "mercury-3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "inception/mercury-3"
    },
    {
      "name": "inclusionAI: Ling 3.0 Flash",
      "aliases": [
        "inclusionai/ling-3.0-flash",
        "Ling 3.0 Flash",
        "ling-3.0-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "inclusionai/ling-3.0-flash"
    },
    {
      "name": "inclusionAI: Ling 3.0 Flash VL",
      "aliases": [
        "inclusionai/ling-3.0-flash-vl",
        "Ling 3.0 Flash VL",
        "ling-3.0-flash-vl"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "inclusionai/ling-3.0-flash-vl"
    },
    {
      "name": "inclusionAI: Ling 3.1 Flash",
      "aliases": [
        "inclusionai/ling-3.1-flash",
        "Ling 3.1 Flash",
        "ling-3.1-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "inclusionai/ling-3.1-flash"
    },
    {
      "name": "Inference.net: Schematron V2 Small",
      "aliases": [
        "inference-net/schematron-v2-small",
        "Schematron V2 Small",
        "schematron-v2-small"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "inference-net/schematron-v2-small"
    },
    {
      "name": "Inference.net: Schematron V2 Turbo",
      "aliases": [
        "inference-net/schematron-v2-turbo",
        "Schematron V2 Turbo",
        "schematron-v2-turbo"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "inference-net/schematron-v2-turbo"
    },
    {
      "name": "LiquidAI: LFM2.5-2.6B",
      "aliases": [
        "liquid/lfm-2.5-2.6b",
        "LFM2.5-2.6B",
        "lfm-2.5-2.6b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "liquid/lfm-2.5-2.6b"
    },
    {
      "name": "LiquidAI: LFM2.5-24B-A2B",
      "aliases": [
        "liquid/lfm-2.5-24b-a2b",
        "LFM2.5-24B-A2B",
        "lfm-2.5-24b-a2b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "liquid/lfm-2.5-24b-a2b"
    },
    {
      "name": "Mancer: Weaver (alpha)",
      "aliases": [
        "mancer/weaver",
        "Weaver (alpha)",
        "weaver"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mancer/weaver"
    },
    {
      "name": "Meituan: LongCat 2.0",
      "aliases": [
        "meituan/longcat-2.0",
        "LongCat 2.0",
        "longcat-2.0"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meituan/longcat-2.0"
    },
    {
      "name": "Meta: Llama 3.1 70B Instruct",
      "aliases": [
        "meta-llama/llama-3.1-70b-instruct",
        "Llama 3.1 70B Instruct",
        "llama-3.1-70b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta-llama/llama-3.1-70b-instruct"
    },
    {
      "name": "Meta: Llama 3.1 8B Instruct",
      "aliases": [
        "meta-llama/llama-3.1-8b-instruct",
        "Llama 3.1 8B Instruct",
        "llama-3.1-8b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta-llama/llama-3.1-8b-instruct"
    },
    {
      "name": "Meta: Llama 3.2 1B Instruct",
      "aliases": [
        "meta-llama/llama-3.2-1b-instruct",
        "Llama 3.2 1B Instruct",
        "llama-3.2-1b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta-llama/llama-3.2-1b-instruct"
    },
    {
      "name": "Meta: Llama 3.2 3B Instruct",
      "aliases": [
        "meta-llama/llama-3.2-3b-instruct",
        "Llama 3.2 3B Instruct",
        "llama-3.2-3b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta-llama/llama-3.2-3b-instruct"
    },
    {
      "name": "Meta: Llama 3.3 70B Instruct",
      "aliases": [
        "meta-llama/llama-3.3-70b-instruct",
        "Llama 3.3 70B Instruct",
        "llama-3.3-70b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta-llama/llama-3.3-70b-instruct"
    },
    {
      "name": "Meta: Llama 4 Maverick",
      "aliases": [
        "meta-llama/llama-4-maverick",
        "Llama 4 Maverick",
        "llama-4-maverick"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta-llama/llama-4-maverick"
    },
    {
      "name": "Meta: Llama 4 Scout",
      "aliases": [
        "meta-llama/llama-4-scout",
        "Llama 4 Scout",
        "llama-4-scout"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta-llama/llama-4-scout"
    },
    {
      "name": "Meta: Llama Guard 4 12B",
      "aliases": [
        "meta-llama/llama-guard-4-12b",
        "Llama Guard 4 12B",
        "llama-guard-4-12b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta-llama/llama-guard-4-12b"
    },
    {
      "name": "Meta: Muse Glimmer 30B",
      "aliases": [
        "meta/muse-glimmer-30b",
        "Muse Glimmer 30B",
        "muse-glimmer-30b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta/muse-glimmer-30b"
    },
    {
      "name": "Meta: Muse Spark 1.1",
      "aliases": [
        "meta/muse-spark-1.1",
        "Muse Spark 1.1",
        "muse-spark-1.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta/muse-spark-1.1"
    },
    {
      "name": "Meta: Muse Spark 1.2",
      "aliases": [
        "meta/muse-spark-1.2",
        "Muse Spark 1.2",
        "muse-spark-1.2"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta/muse-spark-1.2"
    },
    {
      "name": "Meta: Muse Spark 1.2 Contributor",
      "aliases": [
        "meta/muse-spark-1.2-contributor",
        "Muse Spark 1.2 Contributor",
        "muse-spark-1.2-contributor"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta/muse-spark-1.2-contributor"
    },
    {
      "name": "Meta: Muse Spark 1.3",
      "aliases": [
        "meta/muse-spark-1.3",
        "Muse Spark 1.3",
        "muse-spark-1.3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta/muse-spark-1.3"
    },
    {
      "name": "Meta: Muse Spark 1.3 Contributor",
      "aliases": [
        "meta/muse-spark-1.3-contributor",
        "Muse Spark 1.3 Contributor",
        "muse-spark-1.3-contributor"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta/muse-spark-1.3-contributor"
    },
    {
      "name": "Meta: Muse Spark Open",
      "aliases": [
        "meta/muse-spark-open",
        "Muse Spark Open",
        "muse-spark-open"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta/muse-spark-open"
    },
    {
      "name": "Meta: Muse Wonder",
      "aliases": [
        "meta/muse-wonder",
        "Muse Wonder",
        "muse-wonder"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "meta/muse-wonder"
    },
    {
      "name": "Microsoft: Phi 4",
      "aliases": [
        "microsoft/phi-4",
        "Phi 4",
        "phi-4"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "microsoft/phi-4"
    },
    {
      "name": "MiniMax: MiniMax-01",
      "aliases": [
        "minimax/minimax-01",
        "MiniMax-01",
        "minimax-01"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "minimax/minimax-01"
    },
    {
      "name": "MiniMax: MiniMax M1",
      "aliases": [
        "minimax/minimax-m1",
        "MiniMax M1",
        "minimax-m1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "minimax/minimax-m1"
    },
    {
      "name": "MiniMax: MiniMax M2",
      "aliases": [
        "minimax/minimax-m2",
        "MiniMax M2",
        "minimax-m2"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "minimax/minimax-m2"
    },
    {
      "name": "MiniMax: MiniMax M2-her",
      "aliases": [
        "minimax/minimax-m2-her",
        "MiniMax M2-her",
        "minimax-m2-her"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "minimax/minimax-m2-her"
    },
    {
      "name": "MiniMax: MiniMax M2.1",
      "aliases": [
        "minimax/minimax-m2.1",
        "MiniMax M2.1",
        "minimax-m2.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "minimax/minimax-m2.1"
    },
    {
      "name": "MiniMax: MiniMax M2.5",
      "aliases": [
        "minimax/minimax-m2.5",
        "MiniMax M2.5",
        "minimax-m2.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "minimax/minimax-m2.5"
    },
    {
      "name": "MiniMax: MiniMax M2.7",
      "aliases": [
        "minimax/minimax-m2.7",
        "MiniMax M2.7",
        "minimax-m2.7"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "minimax/minimax-m2.7"
    },
    {
      "name": "MiniMax: MiniMax M3",
      "aliases": [
        "minimax/minimax-m3",
        "MiniMax M3",
        "minimax-m3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "minimax/minimax-m3"
    },
    {
      "name": "MiniMax: MiniMax M3.1 Flash",
      "aliases": [
        "minimax/minimax-m3.1-flash",
        "MiniMax M3.1 Flash",
        "minimax-m3.1-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "minimax/minimax-m3.1-flash"
    },
    {
      "name": "Mistral: Codestral 2508",
      "aliases": [
        "mistralai/codestral-2508",
        "Codestral 2508",
        "codestral-2508"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/codestral-2508"
    },
    {
      "name": "Mistral: Devstral 2 2512",
      "aliases": [
        "mistralai/devstral-2512",
        "Devstral 2 2512",
        "devstral-2512"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/devstral-2512"
    },
    {
      "name": "Mistral: Ministral 3 14B 2512",
      "aliases": [
        "mistralai/ministral-14b-2512",
        "Ministral 3 14B 2512",
        "ministral-14b-2512"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/ministral-14b-2512"
    },
    {
      "name": "Mistral: Ministral 3 3B 2512",
      "aliases": [
        "mistralai/ministral-3b-2512",
        "Ministral 3 3B 2512",
        "ministral-3b-2512"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/ministral-3b-2512"
    },
    {
      "name": "Mistral: Ministral 3 8B 2512",
      "aliases": [
        "mistralai/ministral-8b-2512",
        "Ministral 3 8B 2512",
        "ministral-8b-2512"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/ministral-8b-2512"
    },
    {
      "name": "Mistral Large",
      "aliases": [
        "mistralai/mistral-large",
        "Mistral Large",
        "mistral-large"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-large"
    },
    {
      "name": "Mistral Large 2407",
      "aliases": [
        "mistralai/mistral-large-2407",
        "Mistral Large 2407",
        "mistral-large-2407"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-large-2407"
    },
    {
      "name": "Mistral: Mistral Large 3 2512",
      "aliases": [
        "mistralai/mistral-large-2512",
        "Mistral Large 3 2512",
        "mistral-large-2512"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-large-2512"
    },
    {
      "name": "Mistral: Mistral Large 4",
      "aliases": [
        "mistralai/mistral-large-4-0",
        "Mistral Large 4",
        "mistral-large-4-0"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-large-4-0"
    },
    {
      "name": "Mistral: Mistral Medium 3",
      "aliases": [
        "mistralai/mistral-medium-3",
        "Mistral Medium 3",
        "mistral-medium-3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-medium-3"
    },
    {
      "name": "Mistral: Mistral Medium 3.5",
      "aliases": [
        "mistralai/mistral-medium-3-5",
        "Mistral Medium 3.5",
        "mistral-medium-3-5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-medium-3-5"
    },
    {
      "name": "Mistral: Mistral Medium 3.1",
      "aliases": [
        "mistralai/mistral-medium-3.1",
        "Mistral Medium 3.1",
        "mistral-medium-3.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-medium-3.1"
    },
    {
      "name": "Mistral: Mistral Nemo",
      "aliases": [
        "mistralai/mistral-nemo",
        "Mistral Nemo",
        "mistral-nemo"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-nemo"
    },
    {
      "name": "Mistral: Saba",
      "aliases": [
        "mistralai/mistral-saba",
        "Saba",
        "mistral-saba"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-saba"
    },
    {
      "name": "Mistral: Mistral Small 3",
      "aliases": [
        "mistralai/mistral-small-24b-instruct-2501",
        "Mistral Small 3",
        "mistral-small-24b-instruct-2501"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-small-24b-instruct-2501"
    },
    {
      "name": "Mistral: Mistral Small 4",
      "aliases": [
        "mistralai/mistral-small-2603",
        "Mistral Small 4",
        "mistral-small-2603"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-small-2603"
    },
    {
      "name": "Mistral: Mistral Small 3.1 24B",
      "aliases": [
        "mistralai/mistral-small-3.1-24b-instruct",
        "Mistral Small 3.1 24B",
        "mistral-small-3.1-24b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-small-3.1-24b-instruct"
    },
    {
      "name": "Mistral: Mistral Small 3.2 24B",
      "aliases": [
        "mistralai/mistral-small-3.2-24b-instruct",
        "Mistral Small 3.2 24B",
        "mistral-small-3.2-24b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mistral-small-3.2-24b-instruct"
    },
    {
      "name": "Mistral: Mixtral 8x22B Instruct",
      "aliases": [
        "mistralai/mixtral-8x22b-instruct",
        "Mixtral 8x22B Instruct",
        "mixtral-8x22b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/mixtral-8x22b-instruct"
    },
    {
      "name": "Mistral: Voxtral Small 24B 2507",
      "aliases": [
        "mistralai/voxtral-small-24b-2507",
        "Voxtral Small 24B 2507",
        "voxtral-small-24b-2507"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "mistralai/voxtral-small-24b-2507"
    },
    {
      "name": "Moondream: Moondream 3 Preview",
      "aliases": [
        "moondream/moondream3-preview",
        "Moondream 3 Preview",
        "moondream3-preview"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "moondream/moondream3-preview"
    },
    {
      "name": "Moondream: Moondream 3.1",
      "aliases": [
        "moondream/moondream3.1-9b-a2b",
        "Moondream 3.1",
        "moondream3.1-9b-a2b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "moondream/moondream3.1-9b-a2b"
    },
    {
      "name": "MoonshotAI: Kimi K2 0711",
      "aliases": [
        "moonshotai/kimi-k2",
        "Kimi K2 0711",
        "kimi-k2"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "moonshotai/kimi-k2"
    },
    {
      "name": "MoonshotAI: Kimi K2 0905",
      "aliases": [
        "moonshotai/kimi-k2-0905",
        "Kimi K2 0905",
        "kimi-k2-0905"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "moonshotai/kimi-k2-0905"
    },
    {
      "name": "MoonshotAI: Kimi K2 Thinking",
      "aliases": [
        "moonshotai/kimi-k2-thinking",
        "Kimi K2 Thinking",
        "kimi-k2-thinking"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "moonshotai/kimi-k2-thinking"
    },
    {
      "name": "MoonshotAI: Kimi K2.5",
      "aliases": [
        "moonshotai/kimi-k2.5",
        "Kimi K2.5",
        "kimi-k2.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "moonshotai/kimi-k2.5"
    },
    {
      "name": "MoonshotAI: Kimi K2.6",
      "aliases": [
        "moonshotai/kimi-k2.6",
        "Kimi K2.6",
        "kimi-k2.6"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "moonshotai/kimi-k2.6"
    },
    {
      "name": "MoonshotAI: Kimi K2.7 Code",
      "aliases": [
        "moonshotai/kimi-k2.7-code",
        "Kimi K2.7 Code",
        "kimi-k2.7-code"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "moonshotai/kimi-k2.7-code"
    },
    {
      "name": "MoonshotAI: Kimi K3",
      "aliases": [
        "moonshotai/kimi-k3",
        "Kimi K3",
        "kimi-k3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "moonshotai/kimi-k3"
    },
    {
      "name": "MoonshotAI: Kimi K3.1 Pro",
      "aliases": [
        "moonshotai/kimi-k3.1-pro",
        "Kimi K3.1 Pro",
        "kimi-k3.1-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "moonshotai/kimi-k3.1-pro"
    },
    {
      "name": "Morph: Morph V3 Fast",
      "aliases": [
        "morph/morph-v3-fast",
        "Morph V3 Fast",
        "morph-v3-fast"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "morph/morph-v3-fast"
    },
    {
      "name": "Morph: Morph V3 Large",
      "aliases": [
        "morph/morph-v3-large",
        "Morph V3 Large",
        "morph-v3-large"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "morph/morph-v3-large"
    },
    {
      "name": "Nex AGI: Nex-N2.5-Mini",
      "aliases": [
        "nex-agi/nex-n2.5-mini",
        "Nex-N2.5-Mini",
        "nex-n2.5-mini"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nex-agi/nex-n2.5-mini"
    },
    {
      "name": "Nex AGI: Nex-N2.5-Pro",
      "aliases": [
        "nex-agi/nex-n2.5-pro",
        "Nex-N2.5-Pro",
        "nex-n2.5-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nex-agi/nex-n2.5-pro"
    },
    {
      "name": "Nous: Hermes 3 405B Instruct",
      "aliases": [
        "nousresearch/hermes-3-llama-3.1-405b",
        "Hermes 3 405B Instruct",
        "hermes-3-llama-3.1-405b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nousresearch/hermes-3-llama-3.1-405b"
    },
    {
      "name": "Nous: Hermes 3 70B Instruct",
      "aliases": [
        "nousresearch/hermes-3-llama-3.1-70b",
        "Hermes 3 70B Instruct",
        "hermes-3-llama-3.1-70b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nousresearch/hermes-3-llama-3.1-70b"
    },
    {
      "name": "Nous: Hermes 4 405B",
      "aliases": [
        "nousresearch/hermes-4-405b",
        "Hermes 4 405B",
        "hermes-4-405b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nousresearch/hermes-4-405b"
    },
    {
      "name": "NVIDIA: Nemotron 3 Nano 30B A3B",
      "aliases": [
        "nvidia/nemotron-3-nano-30b-a3b",
        "Nemotron 3 Nano 30B A3B",
        "nemotron-3-nano-30b-a3b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nvidia/nemotron-3-nano-30b-a3b"
    },
    {
      "name": "NVIDIA: Nemotron 3 Super",
      "aliases": [
        "nvidia/nemotron-3-super-120b-a12b",
        "Nemotron 3 Super",
        "nemotron-3-super-120b-a12b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nvidia/nemotron-3-super-120b-a12b"
    },
    {
      "name": "NVIDIA: Nemotron 3 Ultra",
      "aliases": [
        "nvidia/nemotron-3-ultra-550b-a55b",
        "Nemotron 3 Ultra",
        "nemotron-3-ultra-550b-a55b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nvidia/nemotron-3-ultra-550b-a55b"
    },
    {
      "name": "NVIDIA: Nemotron 3.5 Content Safety",
      "aliases": [
        "nvidia/nemotron-3.5-content-safety",
        "Nemotron 3.5 Content Safety",
        "nemotron-3.5-content-safety"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nvidia/nemotron-3.5-content-safety"
    },
    {
      "name": "NVIDIA: Nemotron 3.5 Lightning",
      "aliases": [
        "nvidia/nemotron-3.5-lightning",
        "Nemotron 3.5 Lightning",
        "nemotron-3.5-lightning"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nvidia/nemotron-3.5-lightning"
    },
    {
      "name": "NVIDIA: Nemotron 3.5 Super VL",
      "aliases": [
        "nvidia/nemotron-3.5-super-vl",
        "Nemotron 3.5 Super VL",
        "nemotron-3.5-super-vl"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nvidia/nemotron-3.5-super-vl"
    },
    {
      "name": "NVIDIA: Switchyard",
      "aliases": [
        "nvidia/switchyard",
        "Switchyard",
        "switchyard"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "nvidia/switchyard"
    },
    {
      "name": "OpenAI: GPT-3.5 Turbo (older v0613)",
      "aliases": [
        "openai/gpt-3.5-turbo-0613",
        "GPT-3.5 Turbo (older v0613)",
        "gpt-3.5-turbo-0613"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-3.5-turbo-0613"
    },
    {
      "name": "OpenAI: GPT-3.5 Turbo 16k",
      "aliases": [
        "openai/gpt-3.5-turbo-16k",
        "GPT-3.5 Turbo 16k",
        "gpt-3.5-turbo-16k"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-3.5-turbo-16k"
    },
    {
      "name": "OpenAI: GPT-4",
      "aliases": [
        "openai/gpt-4",
        "GPT-4",
        "gpt-4"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-4"
    },
    {
      "name": "OpenAI: GPT-4 Turbo",
      "aliases": [
        "openai/gpt-4-turbo",
        "GPT-4 Turbo",
        "gpt-4-turbo"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-4-turbo"
    },
    {
      "name": "OpenAI: GPT-4.1",
      "aliases": [
        "openai/gpt-4.1",
        "GPT-4.1",
        "gpt-4.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-4.1"
    },
    {
      "name": "OpenAI: GPT-4.1 Mini",
      "aliases": [
        "openai/gpt-4.1-mini",
        "GPT-4.1 Mini",
        "gpt-4.1-mini"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-4.1-mini"
    },
    {
      "name": "OpenAI: GPT-4.1 Nano",
      "aliases": [
        "openai/gpt-4.1-nano",
        "GPT-4.1 Nano",
        "gpt-4.1-nano"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-4.1-nano"
    },
    {
      "name": "OpenAI: GPT-4o",
      "aliases": [
        "openai/gpt-4o",
        "GPT-4o",
        "gpt-4o"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-4o"
    },
    {
      "name": "OpenAI: GPT-4o (2024-05-13)",
      "aliases": [
        "openai/gpt-4o-2024-05-13",
        "GPT-4o (2024-05-13)",
        "gpt-4o-2024-05-13"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-4o-2024-05-13"
    },
    {
      "name": "OpenAI: GPT-4o (2024-08-06)",
      "aliases": [
        "openai/gpt-4o-2024-08-06",
        "GPT-4o (2024-08-06)",
        "gpt-4o-2024-08-06"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-4o-2024-08-06"
    },
    {
      "name": "OpenAI: GPT-4o (2024-11-20)",
      "aliases": [
        "openai/gpt-4o-2024-11-20",
        "GPT-4o (2024-11-20)",
        "gpt-4o-2024-11-20"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-4o-2024-11-20"
    },
    {
      "name": "OpenAI: GPT-4o-mini",
      "aliases": [
        "openai/gpt-4o-mini",
        "GPT-4o-mini",
        "gpt-4o-mini"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-4o-mini"
    },
    {
      "name": "OpenAI: GPT-4o-mini (2024-07-18)",
      "aliases": [
        "openai/gpt-4o-mini-2024-07-18",
        "GPT-4o-mini (2024-07-18)",
        "gpt-4o-mini-2024-07-18"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-4o-mini-2024-07-18"
    },
    {
      "name": "OpenAI: GPT-5",
      "aliases": [
        "openai/gpt-5",
        "GPT-5",
        "gpt-5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5"
    },
    {
      "name": "OpenAI: GPT-5 Mini",
      "aliases": [
        "openai/gpt-5-mini",
        "GPT-5 Mini",
        "gpt-5-mini"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5-mini"
    },
    {
      "name": "OpenAI: GPT-5 Nano",
      "aliases": [
        "openai/gpt-5-nano",
        "GPT-5 Nano",
        "gpt-5-nano"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5-nano"
    },
    {
      "name": "OpenAI: GPT-5 Pro",
      "aliases": [
        "openai/gpt-5-pro",
        "GPT-5 Pro",
        "gpt-5-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5-pro"
    },
    {
      "name": "OpenAI: GPT-5.1",
      "aliases": [
        "openai/gpt-5.1",
        "GPT-5.1",
        "gpt-5.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.1"
    },
    {
      "name": "OpenAI: GPT-5.1-Codex",
      "aliases": [
        "openai/gpt-5.1-codex",
        "GPT-5.1-Codex",
        "gpt-5.1-codex"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.1-codex"
    },
    {
      "name": "OpenAI: GPT-5.1-Codex-Max",
      "aliases": [
        "openai/gpt-5.1-codex-max",
        "GPT-5.1-Codex-Max",
        "gpt-5.1-codex-max"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.1-codex-max"
    },
    {
      "name": "OpenAI: GPT-5.1-Codex-Mini",
      "aliases": [
        "openai/gpt-5.1-codex-mini",
        "GPT-5.1-Codex-Mini",
        "gpt-5.1-codex-mini"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.1-codex-mini"
    },
    {
      "name": "OpenAI: GPT-5.2",
      "aliases": [
        "openai/gpt-5.2",
        "GPT-5.2",
        "gpt-5.2"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.2"
    },
    {
      "name": "OpenAI: GPT-5.2 Chat",
      "aliases": [
        "openai/gpt-5.2-chat",
        "GPT-5.2 Chat",
        "gpt-5.2-chat"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.2-chat"
    },
    {
      "name": "OpenAI: GPT-5.2-Codex",
      "aliases": [
        "openai/gpt-5.2-codex",
        "GPT-5.2-Codex",
        "gpt-5.2-codex"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.2-codex"
    },
    {
      "name": "OpenAI: GPT-5.2 Pro",
      "aliases": [
        "openai/gpt-5.2-pro",
        "GPT-5.2 Pro",
        "gpt-5.2-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.2-pro"
    },
    {
      "name": "OpenAI: GPT-5.3-Codex",
      "aliases": [
        "openai/gpt-5.3-codex",
        "GPT-5.3-Codex",
        "gpt-5.3-codex"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.3-codex"
    },
    {
      "name": "OpenAI: GPT-5.4",
      "aliases": [
        "openai/gpt-5.4",
        "GPT-5.4",
        "gpt-5.4"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.4"
    },
    {
      "name": "OpenAI: GPT-5.4 Mini",
      "aliases": [
        "openai/gpt-5.4-mini",
        "GPT-5.4 Mini",
        "gpt-5.4-mini"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.4-mini"
    },
    {
      "name": "OpenAI: GPT-5.4 Nano",
      "aliases": [
        "openai/gpt-5.4-nano",
        "GPT-5.4 Nano",
        "gpt-5.4-nano"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.4-nano"
    },
    {
      "name": "OpenAI: GPT-5.4 Pro",
      "aliases": [
        "openai/gpt-5.4-pro",
        "GPT-5.4 Pro",
        "gpt-5.4-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.4-pro"
    },
    {
      "name": "OpenAI: GPT-5.5",
      "aliases": [
        "openai/gpt-5.5",
        "GPT-5.5",
        "gpt-5.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.5"
    },
    {
      "name": "OpenAI: GPT-5.5 Pro",
      "aliases": [
        "openai/gpt-5.5-pro",
        "GPT-5.5 Pro",
        "gpt-5.5-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.5-pro"
    },
    {
      "name": "OpenAI: GPT-5.6 Luna",
      "aliases": [
        "openai/gpt-5.6-luna",
        "GPT-5.6 Luna",
        "gpt-5.6-luna"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.6-luna"
    },
    {
      "name": "OpenAI: GPT-5.6 Luna Pro",
      "aliases": [
        "openai/gpt-5.6-luna-pro",
        "GPT-5.6 Luna Pro",
        "gpt-5.6-luna-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.6-luna-pro"
    },
    {
      "name": "OpenAI: GPT-5.6 Sol",
      "aliases": [
        "openai/gpt-5.6-sol",
        "GPT-5.6 Sol",
        "gpt-5.6-sol"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.6-sol"
    },
    {
      "name": "OpenAI: GPT-5.6 Sol Pro",
      "aliases": [
        "openai/gpt-5.6-sol-pro",
        "GPT-5.6 Sol Pro",
        "gpt-5.6-sol-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.6-sol-pro"
    },
    {
      "name": "OpenAI: GPT-5.6 Terra",
      "aliases": [
        "openai/gpt-5.6-terra",
        "GPT-5.6 Terra",
        "gpt-5.6-terra"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.6-terra"
    },
    {
      "name": "OpenAI: GPT-5.6 Terra Pro",
      "aliases": [
        "openai/gpt-5.6-terra-pro",
        "GPT-5.6 Terra Pro",
        "gpt-5.6-terra-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-5.6-terra-pro"
    },
    {
      "name": "OpenAI: GPT-6 Astra",
      "aliases": [
        "openai/gpt-6-astra",
        "GPT-6 Astra",
        "gpt-6-astra"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-6-astra"
    },
    {
      "name": "OpenAI: GPT-6 Astra Pro",
      "aliases": [
        "openai/gpt-6-astra-pro",
        "GPT-6 Astra Pro",
        "gpt-6-astra-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-6-astra-pro"
    },
    {
      "name": "OpenAI: GPT-6 Luna",
      "aliases": [
        "openai/gpt-6-luna",
        "GPT-6 Luna",
        "gpt-6-luna"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-6-luna"
    },
    {
      "name": "OpenAI: GPT-6 Luna Pro",
      "aliases": [
        "openai/gpt-6-luna-pro",
        "GPT-6 Luna Pro",
        "gpt-6-luna-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-6-luna-pro"
    },
    {
      "name": "OpenAI: GPT-6 Sol",
      "aliases": [
        "openai/gpt-6-sol",
        "GPT-6 Sol",
        "gpt-6-sol"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-6-sol"
    },
    {
      "name": "OpenAI: GPT-6 Sol Pro",
      "aliases": [
        "openai/gpt-6-sol-pro",
        "GPT-6 Sol Pro",
        "gpt-6-sol-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-6-sol-pro"
    },
    {
      "name": "OpenAI: GPT-6.1 Sol",
      "aliases": [
        "openai/gpt-6.1-sol",
        "GPT-6.1 Sol",
        "gpt-6.1-sol"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-6.1-sol"
    },
    {
      "name": "OpenAI: GPT-6.1 Sol Pro",
      "aliases": [
        "openai/gpt-6.1-sol-pro",
        "GPT-6.1 Sol Pro",
        "gpt-6.1-sol-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-6.1-sol-pro"
    },
    {
      "name": "OpenAI: GPT-6.1 Terra",
      "aliases": [
        "openai/gpt-6.1-terra",
        "GPT-6.1 Terra",
        "gpt-6.1-terra"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-6.1-terra"
    },
    {
      "name": "OpenAI: GPT-6.1 Terra Pro",
      "aliases": [
        "openai/gpt-6.1-terra-pro",
        "GPT-6.1 Terra Pro",
        "gpt-6.1-terra-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-6.1-terra-pro"
    },
    {
      "name": "OpenAI: GPT Chat Latest",
      "aliases": [
        "openai/gpt-chat-latest",
        "GPT Chat Latest",
        "gpt-chat-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-chat-latest"
    },
    {
      "name": "OpenAI: gpt-oss-120b",
      "aliases": [
        "openai/gpt-oss-120b",
        "gpt-oss-120b",
        "gpt-oss-120b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-oss-120b"
    },
    {
      "name": "OpenAI: gpt-oss-20b",
      "aliases": [
        "openai/gpt-oss-20b",
        "gpt-oss-20b",
        "gpt-oss-20b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-oss-20b"
    },
    {
      "name": "OpenAI: gpt-oss-safeguard-20b",
      "aliases": [
        "openai/gpt-oss-safeguard-20b",
        "gpt-oss-safeguard-20b",
        "gpt-oss-safeguard-20b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/gpt-oss-safeguard-20b"
    },
    {
      "name": "OpenAI: o1",
      "aliases": [
        "openai/o1",
        "o1",
        "o1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/o1"
    },
    {
      "name": "OpenAI: o1-pro",
      "aliases": [
        "openai/o1-pro",
        "o1-pro",
        "o1-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/o1-pro"
    },
    {
      "name": "OpenAI: o3",
      "aliases": [
        "openai/o3",
        "o3",
        "o3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/o3"
    },
    {
      "name": "OpenAI: o3 Mini",
      "aliases": [
        "openai/o3-mini",
        "o3 Mini",
        "o3-mini"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/o3-mini"
    },
    {
      "name": "OpenAI: o3 Mini High",
      "aliases": [
        "openai/o3-mini-high",
        "o3 Mini High",
        "o3-mini-high"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/o3-mini-high"
    },
    {
      "name": "OpenAI: o3 Pro",
      "aliases": [
        "openai/o3-pro",
        "o3 Pro",
        "o3-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/o3-pro"
    },
    {
      "name": "OpenAI: o4 Mini",
      "aliases": [
        "openai/o4-mini",
        "o4 Mini",
        "o4-mini"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/o4-mini"
    },
    {
      "name": "OpenAI: o4 Mini High",
      "aliases": [
        "openai/o4-mini-high",
        "o4 Mini High",
        "o4-mini-high"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openai/o4-mini-high"
    },
    {
      "name": "Body Builder (beta)",
      "aliases": [
        "openrouter/bodybuilder",
        "Body Builder (beta)",
        "bodybuilder"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openrouter/bodybuilder"
    },
    {
      "name": "Free Models Router",
      "aliases": [
        "openrouter/free",
        "Free Models Router",
        "free"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openrouter/free"
    },
    {
      "name": "OpenRouter: Fusion",
      "aliases": [
        "openrouter/fusion",
        "Fusion",
        "fusion"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openrouter/fusion"
    },
    {
      "name": "Pareto Code Router",
      "aliases": [
        "openrouter/pareto-code",
        "Pareto Code Router",
        "pareto-code"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "openrouter/pareto-code"
    },
    {
      "name": "Perceptron: Perceptron Mk1",
      "aliases": [
        "perceptron/perceptron-mk1",
        "Perceptron Mk1",
        "perceptron-mk1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "perceptron/perceptron-mk1"
    },
    {
      "name": "Perceptron: Perceptron Mk1.5",
      "aliases": [
        "perceptron/perceptron-mk1.5",
        "Perceptron Mk1.5",
        "perceptron-mk1.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "perceptron/perceptron-mk1.5"
    },
    {
      "name": "Perplexity: Sonar",
      "aliases": [
        "perplexity/sonar",
        "Sonar",
        "sonar"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "perplexity/sonar"
    },
    {
      "name": "Perplexity: Sonar Deep Research",
      "aliases": [
        "perplexity/sonar-deep-research",
        "Sonar Deep Research",
        "sonar-deep-research"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "perplexity/sonar-deep-research"
    },
    {
      "name": "Perplexity: Sonar Pro",
      "aliases": [
        "perplexity/sonar-pro",
        "Sonar Pro",
        "sonar-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "perplexity/sonar-pro"
    },
    {
      "name": "Perplexity: Sonar Pro Search",
      "aliases": [
        "perplexity/sonar-pro-search",
        "Sonar Pro Search",
        "sonar-pro-search"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "perplexity/sonar-pro-search"
    },
    {
      "name": "Perplexity: Sonar Reasoning Pro",
      "aliases": [
        "perplexity/sonar-reasoning-pro",
        "Sonar Reasoning Pro",
        "sonar-reasoning-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "perplexity/sonar-reasoning-pro"
    },
    {
      "name": "Poolside: Laguna S 2.1",
      "aliases": [
        "poolside/laguna-s-2.1",
        "Laguna S 2.1",
        "laguna-s-2.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "poolside/laguna-s-2.1"
    },
    {
      "name": "Poolside: Laguna XS 2.1",
      "aliases": [
        "poolside/laguna-xs-2.1",
        "Laguna XS 2.1",
        "laguna-xs-2.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "poolside/laguna-xs-2.1"
    },
    {
      "name": "PrismML: Ternary Bonsai 2 27B",
      "aliases": [
        "prism-ml/ternary-bonsai-2-27b",
        "Ternary Bonsai 2 27B",
        "ternary-bonsai-2-27b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "prism-ml/ternary-bonsai-2-27b"
    },
    {
      "name": "Qwen2.5 72B Instruct",
      "aliases": [
        "qwen/qwen-2.5-72b-instruct",
        "Qwen2.5 72B Instruct",
        "qwen-2.5-72b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen-2.5-72b-instruct"
    },
    {
      "name": "Qwen: Qwen2.5 7B Instruct",
      "aliases": [
        "qwen/qwen-2.5-7b-instruct",
        "Qwen2.5 7B Instruct",
        "qwen-2.5-7b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen-2.5-7b-instruct"
    },
    {
      "name": "Qwen2.5 Coder 32B Instruct",
      "aliases": [
        "qwen/qwen-2.5-coder-32b-instruct",
        "Qwen2.5 Coder 32B Instruct",
        "qwen-2.5-coder-32b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen-2.5-coder-32b-instruct"
    },
    {
      "name": "Qwen: Qwen-Plus",
      "aliases": [
        "qwen/qwen-plus",
        "Qwen-Plus",
        "qwen-plus"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen-plus"
    },
    {
      "name": "Qwen: Qwen2.5 VL 72B Instruct",
      "aliases": [
        "qwen/qwen2.5-vl-72b-instruct",
        "Qwen2.5 VL 72B Instruct",
        "qwen2.5-vl-72b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen2.5-vl-72b-instruct"
    },
    {
      "name": "Qwen: Qwen3 14B",
      "aliases": [
        "qwen/qwen3-14b",
        "Qwen3 14B",
        "qwen3-14b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-14b"
    },
    {
      "name": "Qwen: Qwen3 235B A22B Instruct 2507",
      "aliases": [
        "qwen/qwen3-235b-a22b-2507",
        "Qwen3 235B A22B Instruct 2507",
        "qwen3-235b-a22b-2507"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-235b-a22b-2507"
    },
    {
      "name": "Qwen: Qwen3 235B A22B Thinking 2507",
      "aliases": [
        "qwen/qwen3-235b-a22b-thinking-2507",
        "Qwen3 235B A22B Thinking 2507",
        "qwen3-235b-a22b-thinking-2507"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-235b-a22b-thinking-2507"
    },
    {
      "name": "Qwen: Qwen3 30B A3B",
      "aliases": [
        "qwen/qwen3-30b-a3b",
        "Qwen3 30B A3B",
        "qwen3-30b-a3b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-30b-a3b"
    },
    {
      "name": "Qwen: Qwen3 30B A3B Instruct 2507",
      "aliases": [
        "qwen/qwen3-30b-a3b-instruct-2507",
        "Qwen3 30B A3B Instruct 2507",
        "qwen3-30b-a3b-instruct-2507"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-30b-a3b-instruct-2507"
    },
    {
      "name": "Qwen: Qwen3 32B",
      "aliases": [
        "qwen/qwen3-32b",
        "Qwen3 32B",
        "qwen3-32b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-32b"
    },
    {
      "name": "Qwen: Qwen3 Coder 480B A35B",
      "aliases": [
        "qwen/qwen3-coder",
        "Qwen3 Coder 480B A35B",
        "qwen3-coder"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-coder"
    },
    {
      "name": "Qwen: Qwen3 Coder 30B A3B Instruct",
      "aliases": [
        "qwen/qwen3-coder-30b-a3b-instruct",
        "Qwen3 Coder 30B A3B Instruct",
        "qwen3-coder-30b-a3b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-coder-30b-a3b-instruct"
    },
    {
      "name": "Qwen: Qwen3 Coder Flash",
      "aliases": [
        "qwen/qwen3-coder-flash",
        "Qwen3 Coder Flash",
        "qwen3-coder-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-coder-flash"
    },
    {
      "name": "Qwen: Qwen3 Coder Next",
      "aliases": [
        "qwen/qwen3-coder-next",
        "Qwen3 Coder Next",
        "qwen3-coder-next"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-coder-next"
    },
    {
      "name": "Qwen: Qwen3 Next 80B A3B Instruct",
      "aliases": [
        "qwen/qwen3-next-80b-a3b-instruct",
        "Qwen3 Next 80B A3B Instruct",
        "qwen3-next-80b-a3b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-next-80b-a3b-instruct"
    },
    {
      "name": "Qwen: Qwen3 Next 80B A3B Thinking",
      "aliases": [
        "qwen/qwen3-next-80b-a3b-thinking",
        "Qwen3 Next 80B A3B Thinking",
        "qwen3-next-80b-a3b-thinking"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-next-80b-a3b-thinking"
    },
    {
      "name": "Qwen: Qwen3 VL 235B A22B Instruct",
      "aliases": [
        "qwen/qwen3-vl-235b-a22b-instruct",
        "Qwen3 VL 235B A22B Instruct",
        "qwen3-vl-235b-a22b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-vl-235b-a22b-instruct"
    },
    {
      "name": "Qwen: Qwen3 VL 30B A3B Instruct",
      "aliases": [
        "qwen/qwen3-vl-30b-a3b-instruct",
        "Qwen3 VL 30B A3B Instruct",
        "qwen3-vl-30b-a3b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-vl-30b-a3b-instruct"
    },
    {
      "name": "Qwen: Qwen3 VL 30B A3B Thinking",
      "aliases": [
        "qwen/qwen3-vl-30b-a3b-thinking",
        "Qwen3 VL 30B A3B Thinking",
        "qwen3-vl-30b-a3b-thinking"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-vl-30b-a3b-thinking"
    },
    {
      "name": "Qwen: Qwen3 VL 8B Instruct",
      "aliases": [
        "qwen/qwen3-vl-8b-instruct",
        "Qwen3 VL 8B Instruct",
        "qwen3-vl-8b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3-vl-8b-instruct"
    },
    {
      "name": "Qwen: Qwen3.5-122B-A10B",
      "aliases": [
        "qwen/qwen3.5-122b-a10b",
        "Qwen3.5-122B-A10B",
        "qwen3.5-122b-a10b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.5-122b-a10b"
    },
    {
      "name": "Qwen: Qwen3.5-27B",
      "aliases": [
        "qwen/qwen3.5-27b",
        "Qwen3.5-27B",
        "qwen3.5-27b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.5-27b"
    },
    {
      "name": "Qwen: Qwen3.5-35B-A3B",
      "aliases": [
        "qwen/qwen3.5-35b-a3b",
        "Qwen3.5-35B-A3B",
        "qwen3.5-35b-a3b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.5-35b-a3b"
    },
    {
      "name": "Qwen: Qwen3.5 397B A17B",
      "aliases": [
        "qwen/qwen3.5-397b-a17b",
        "Qwen3.5 397B A17B",
        "qwen3.5-397b-a17b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.5-397b-a17b"
    },
    {
      "name": "Qwen: Qwen3.5-9B",
      "aliases": [
        "qwen/qwen3.5-9b",
        "Qwen3.5-9B",
        "qwen3.5-9b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.5-9b"
    },
    {
      "name": "Qwen: Qwen3.5-Flash",
      "aliases": [
        "qwen/qwen3.5-flash-02-23",
        "Qwen3.5-Flash",
        "qwen3.5-flash-02-23"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.5-flash-02-23"
    },
    {
      "name": "Qwen: Qwen3.5 Plus 2026-02-15",
      "aliases": [
        "qwen/qwen3.5-plus-02-15",
        "Qwen3.5 Plus 2026-02-15",
        "qwen3.5-plus-02-15"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.5-plus-02-15"
    },
    {
      "name": "Qwen: Qwen3.5 Plus 2026-04-20",
      "aliases": [
        "qwen/qwen3.5-plus-20260420",
        "Qwen3.5 Plus 2026-04-20",
        "qwen3.5-plus-20260420"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.5-plus-20260420"
    },
    {
      "name": "Qwen: Qwen3.6 27B",
      "aliases": [
        "qwen/qwen3.6-27b",
        "Qwen3.6 27B",
        "qwen3.6-27b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.6-27b"
    },
    {
      "name": "Qwen: Qwen3.6 35B A3B",
      "aliases": [
        "qwen/qwen3.6-35b-a3b",
        "Qwen3.6 35B A3B",
        "qwen3.6-35b-a3b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.6-35b-a3b"
    },
    {
      "name": "Qwen: Qwen3.6 Flash",
      "aliases": [
        "qwen/qwen3.6-flash",
        "Qwen3.6 Flash",
        "qwen3.6-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.6-flash"
    },
    {
      "name": "Qwen: Qwen3.6 Plus",
      "aliases": [
        "qwen/qwen3.6-plus",
        "Qwen3.6 Plus",
        "qwen3.6-plus"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.6-plus"
    },
    {
      "name": "Qwen: Qwen3.7 Flash",
      "aliases": [
        "qwen/qwen3.7-flash",
        "Qwen3.7 Flash",
        "qwen3.7-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.7-flash"
    },
    {
      "name": "Qwen: Qwen3.7 Max",
      "aliases": [
        "qwen/qwen3.7-max",
        "Qwen3.7 Max",
        "qwen3.7-max"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.7-max"
    },
    {
      "name": "Qwen: Qwen3.7 Plus",
      "aliases": [
        "qwen/qwen3.7-plus",
        "Qwen3.7 Plus",
        "qwen3.7-plus"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.7-plus"
    },
    {
      "name": "Qwen: Qwen3.8 2.4T A95B",
      "aliases": [
        "qwen/qwen3.8-2.4t-a95b",
        "Qwen3.8 2.4T A95B",
        "qwen3.8-2.4t-a95b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.8-2.4t-a95b"
    },
    {
      "name": "Qwen: Qwen3.8 27B",
      "aliases": [
        "qwen/qwen3.8-27b",
        "Qwen3.8 27B",
        "qwen3.8-27b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.8-27b"
    },
    {
      "name": "Qwen: Qwen3.8 Flash",
      "aliases": [
        "qwen/qwen3.8-flash",
        "Qwen3.8 Flash",
        "qwen3.8-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.8-flash"
    },
    {
      "name": "Qwen: Qwen3.8 Max (0902)",
      "aliases": [
        "qwen/qwen3.8-max-0902",
        "Qwen3.8 Max (0902)",
        "qwen3.8-max-0902"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.8-max-0902"
    },
    {
      "name": "Qwen: Qwen3.8 Max Prime",
      "aliases": [
        "qwen/qwen3.8-max-prime",
        "Qwen3.8 Max Prime",
        "qwen3.8-max-prime"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.8-max-prime"
    },
    {
      "name": "Qwen: Qwen3.8 Omni Flash",
      "aliases": [
        "qwen/qwen3.8-omni-flash",
        "Qwen3.8 Omni Flash",
        "qwen3.8-omni-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "qwen/qwen3.8-omni-flash"
    },
    {
      "name": "Reflection: Beam 1.0 501B A23B",
      "aliases": [
        "reflection/beam-1.0-501b-a23b",
        "Beam 1.0 501B A23B",
        "beam-1.0-501b-a23b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "reflection/beam-1.0-501b-a23b"
    },
    {
      "name": "Reka Edge",
      "aliases": [
        "rekaai/reka-edge",
        "Reka Edge",
        "reka-edge"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "rekaai/reka-edge"
    },
    {
      "name": "Reka Flash 3",
      "aliases": [
        "rekaai/reka-flash-3",
        "Reka Flash 3",
        "reka-flash-3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "rekaai/reka-flash-3"
    },
    {
      "name": "Relace: Relace Apply 3",
      "aliases": [
        "relace/relace-apply-3",
        "Relace Apply 3",
        "relace-apply-3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "relace/relace-apply-3"
    },
    {
      "name": "Relace: Relace Search",
      "aliases": [
        "relace/relace-search",
        "Relace Search",
        "relace-search"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "relace/relace-search"
    },
    {
      "name": "Sakana: Fugu Max",
      "aliases": [
        "sakana/fugu-max",
        "Fugu Max",
        "fugu-max"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "sakana/fugu-max"
    },
    {
      "name": "Sakana: Fugu Ultra",
      "aliases": [
        "sakana/fugu-ultra",
        "Fugu Ultra",
        "fugu-ultra"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "sakana/fugu-ultra"
    },
    {
      "name": "Sakana: Fugu Ultra v2",
      "aliases": [
        "sakana/fugu-ultra-v2",
        "Fugu Ultra v2",
        "fugu-ultra-v2"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "sakana/fugu-ultra-v2"
    },
    {
      "name": "Sakana: Sakana Namazu",
      "aliases": [
        "sakana/sakana-namazu",
        "Sakana Namazu",
        "sakana-namazu"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "sakana/sakana-namazu"
    },
    {
      "name": "Sao10K: Llama 3 8B Lunaris",
      "aliases": [
        "sao10k/l3-lunaris-8b",
        "Llama 3 8B Lunaris",
        "l3-lunaris-8b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "sao10k/l3-lunaris-8b"
    },
    {
      "name": "Sao10K: Llama 3.1 Euryale 70B v2.2",
      "aliases": [
        "sao10k/l3.1-euryale-70b",
        "Llama 3.1 Euryale 70B v2.2",
        "l3.1-euryale-70b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "sao10k/l3.1-euryale-70b"
    },
    {
      "name": "ScaleDown: Extract",
      "aliases": [
        "scaledown/extract",
        "Extract",
        "extract"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "scaledown/extract"
    },
    {
      "name": "ScaleDown: Summarize",
      "aliases": [
        "scaledown/summarize",
        "Summarize",
        "summarize"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "scaledown/summarize"
    },
    {
      "name": "StepFun: Step 3.5 Flash",
      "aliases": [
        "stepfun/step-3.5-flash",
        "Step 3.5 Flash",
        "step-3.5-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "stepfun/step-3.5-flash"
    },
    {
      "name": "StepFun: Step 3.7 Flash",
      "aliases": [
        "stepfun/step-3.7-flash",
        "Step 3.7 Flash",
        "step-3.7-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "stepfun/step-3.7-flash"
    },
    {
      "name": "StepFun: Step 5 Preview",
      "aliases": [
        "stepfun/step-5-preview",
        "Step 5 Preview",
        "step-5-preview"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "stepfun/step-5-preview"
    },
    {
      "name": "Tencent: Hunyuan A13B Instruct",
      "aliases": [
        "tencent/hunyuan-a13b-instruct",
        "Hunyuan A13B Instruct",
        "hunyuan-a13b-instruct"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "tencent/hunyuan-a13b-instruct"
    },
    {
      "name": "Tencent: Hy-MT2-1.8B",
      "aliases": [
        "tencent/hy-mt2-1.8b",
        "Hy-MT2-1.8B",
        "hy-mt2-1.8b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "tencent/hy-mt2-1.8b"
    },
    {
      "name": "Tencent: Hy-MT2-30B-A3B",
      "aliases": [
        "tencent/hy-mt2-30b-a3b",
        "Hy-MT2-30B-A3B",
        "hy-mt2-30b-a3b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "tencent/hy-mt2-30b-a3b"
    },
    {
      "name": "Tencent: Hy-MT2-7B",
      "aliases": [
        "tencent/hy-mt2-7b",
        "Hy-MT2-7B",
        "hy-mt2-7b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "tencent/hy-mt2-7b"
    },
    {
      "name": "Tencent: Hy3",
      "aliases": [
        "tencent/hy3",
        "Hy3",
        "hy3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "tencent/hy3"
    },
    {
      "name": "Tencent: Hy3 preview",
      "aliases": [
        "tencent/hy3-preview",
        "Hy3 preview",
        "hy3-preview"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "tencent/hy3-preview"
    },
    {
      "name": "Tencent: Hy4 preview",
      "aliases": [
        "tencent/hy4-preview",
        "Hy4 preview",
        "hy4-preview"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "tencent/hy4-preview"
    },
    {
      "name": "TheDrummer: Cydonia 24B V4.1",
      "aliases": [
        "thedrummer/cydonia-24b-v4.1",
        "Cydonia 24B V4.1",
        "cydonia-24b-v4.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "thedrummer/cydonia-24b-v4.1"
    },
    {
      "name": "TheDrummer: Skyfall 36B V2",
      "aliases": [
        "thedrummer/skyfall-36b-v2",
        "Skyfall 36B V2",
        "skyfall-36b-v2"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "thedrummer/skyfall-36b-v2"
    },
    {
      "name": "TheDrummer: UnslopNemo 12B",
      "aliases": [
        "thedrummer/unslopnemo-12b",
        "UnslopNemo 12B",
        "unslopnemo-12b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "thedrummer/unslopnemo-12b"
    },
    {
      "name": "Thinking Machines: Inkling",
      "aliases": [
        "thinkingmachines/inkling",
        "Inkling",
        "inkling"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "thinkingmachines/inkling"
    },
    {
      "name": "Thinking Machines: Inkling Small",
      "aliases": [
        "thinkingmachines/inkling-small",
        "Inkling Small",
        "inkling-small"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "thinkingmachines/inkling-small"
    },
    {
      "name": "TypeSafe: Jev Router",
      "aliases": [
        "typesafe/jev-router",
        "Jev Router",
        "jev-router"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "typesafe/jev-router"
    },
    {
      "name": "Pareto 26.10",
      "aliases": [
        "unbiased/pareto-26.10",
        "Pareto 26.10",
        "pareto-26.10"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "unbiased/pareto-26.10"
    },
    {
      "name": "Pareto 26.9",
      "aliases": [
        "unbiased/pareto-26.9",
        "Pareto 26.9",
        "pareto-26.9"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "unbiased/pareto-26.9"
    },
    {
      "name": "ReMM SLERP 13B",
      "aliases": [
        "undi95/remm-slerp-l2-13b",
        "ReMM SLERP 13B",
        "remm-slerp-l2-13b"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "undi95/remm-slerp-l2-13b"
    },
    {
      "name": "Upstage: Solar Mini 4",
      "aliases": [
        "upstage/solar-mini4",
        "Solar Mini 4",
        "solar-mini4"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "upstage/solar-mini4"
    },
    {
      "name": "Upstage: Solar Pro 3",
      "aliases": [
        "upstage/solar-pro-3",
        "Solar Pro 3",
        "solar-pro-3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "upstage/solar-pro-3"
    },
    {
      "name": "Upstage: Solar Pro 4",
      "aliases": [
        "upstage/solar-pro4",
        "Solar Pro 4",
        "solar-pro4"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "upstage/solar-pro4"
    },
    {
      "name": "Writer: Palmyra X5",
      "aliases": [
        "writer/palmyra-x5",
        "Palmyra X5",
        "palmyra-x5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "writer/palmyra-x5"
    },
    {
      "name": "SpaceXAI: Grok 4.20",
      "aliases": [
        "x-ai/grok-4.20",
        "Grok 4.20",
        "grok-4.20"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "x-ai/grok-4.20"
    },
    {
      "name": "SpaceXAI: Grok 4.20 Multi-Agent",
      "aliases": [
        "x-ai/grok-4.20-multi-agent",
        "Grok 4.20 Multi-Agent",
        "grok-4.20-multi-agent"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "x-ai/grok-4.20-multi-agent"
    },
    {
      "name": "SpaceXAI: Grok 4.3",
      "aliases": [
        "x-ai/grok-4.3",
        "Grok 4.3",
        "grok-4.3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "x-ai/grok-4.3"
    },
    {
      "name": "SpaceXAI: Grok 4.5",
      "aliases": [
        "x-ai/grok-4.5",
        "Grok 4.5",
        "grok-4.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "x-ai/grok-4.5"
    },
    {
      "name": "SpaceXAI: Grok 4.6",
      "aliases": [
        "x-ai/grok-4.6",
        "Grok 4.6",
        "grok-4.6"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "x-ai/grok-4.6"
    },
    {
      "name": "SpaceXAI: Grok 4.7",
      "aliases": [
        "x-ai/grok-4.7",
        "Grok 4.7",
        "grok-4.7"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "x-ai/grok-4.7"
    },
    {
      "name": "SpaceXAI: Grok Build 0.1",
      "aliases": [
        "x-ai/grok-build-0.1",
        "Grok Build 0.1",
        "grok-build-0.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "x-ai/grok-build-0.1"
    },
    {
      "name": "Xiaomi: MiMo-V2.5",
      "aliases": [
        "xiaomi/mimo-v2.5",
        "MiMo-V2.5",
        "mimo-v2.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "xiaomi/mimo-v2.5"
    },
    {
      "name": "Xiaomi: MiMo-V2.5-Pro",
      "aliases": [
        "xiaomi/mimo-v2.5-pro",
        "MiMo-V2.5-Pro",
        "mimo-v2.5-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "xiaomi/mimo-v2.5-pro"
    },
    {
      "name": "Xiaomi: MiMo-V2.6-Flash",
      "aliases": [
        "xiaomi/mimo-v2.6-flash",
        "MiMo-V2.6-Flash",
        "mimo-v2.6-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "xiaomi/mimo-v2.6-flash"
    },
    {
      "name": "Xiaomi: MiMo-V2.6-Pro",
      "aliases": [
        "xiaomi/mimo-v2.6-pro",
        "MiMo-V2.6-Pro",
        "mimo-v2.6-pro"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "xiaomi/mimo-v2.6-pro"
    },
    {
      "name": "Xiaomi: MiMo-V2.6-Pro-UltraSpeed",
      "aliases": [
        "xiaomi/mimo-v2.6-pro-ultraspeed",
        "MiMo-V2.6-Pro-UltraSpeed",
        "mimo-v2.6-pro-ultraspeed"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "xiaomi/mimo-v2.6-pro-ultraspeed"
    },
    {
      "name": "Z.ai: GLM 4.5",
      "aliases": [
        "z-ai/glm-4.5",
        "GLM 4.5",
        "glm-4.5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-4.5"
    },
    {
      "name": "Z.ai: GLM 4.5 Air",
      "aliases": [
        "z-ai/glm-4.5-air",
        "GLM 4.5 Air",
        "glm-4.5-air"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-4.5-air"
    },
    {
      "name": "Z.ai: GLM 4.5V",
      "aliases": [
        "z-ai/glm-4.5v",
        "GLM 4.5V",
        "glm-4.5v"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-4.5v"
    },
    {
      "name": "Z.ai: GLM 4.6",
      "aliases": [
        "z-ai/glm-4.6",
        "GLM 4.6",
        "glm-4.6"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-4.6"
    },
    {
      "name": "Z.ai: GLM 4.6V",
      "aliases": [
        "z-ai/glm-4.6v",
        "GLM 4.6V",
        "glm-4.6v"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-4.6v"
    },
    {
      "name": "Z.ai: GLM 4.7",
      "aliases": [
        "z-ai/glm-4.7",
        "GLM 4.7",
        "glm-4.7"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-4.7"
    },
    {
      "name": "Z.ai: GLM 4.7 Flash",
      "aliases": [
        "z-ai/glm-4.7-flash",
        "GLM 4.7 Flash",
        "glm-4.7-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-4.7-flash"
    },
    {
      "name": "Z.ai: GLM 5",
      "aliases": [
        "z-ai/glm-5",
        "GLM 5",
        "glm-5"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-5"
    },
    {
      "name": "Z.ai: GLM 5 Turbo",
      "aliases": [
        "z-ai/glm-5-turbo",
        "GLM 5 Turbo",
        "glm-5-turbo"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-5-turbo"
    },
    {
      "name": "Z.ai: GLM 5.1",
      "aliases": [
        "z-ai/glm-5.1",
        "GLM 5.1",
        "glm-5.1"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-5.1"
    },
    {
      "name": "Z.ai: GLM 5.2",
      "aliases": [
        "z-ai/glm-5.2",
        "GLM 5.2",
        "glm-5.2"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-5.2"
    },
    {
      "name": "Z.ai: GLM 5.3",
      "aliases": [
        "z-ai/glm-5.3",
        "GLM 5.3",
        "glm-5.3"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-5.3"
    },
    {
      "name": "Z.ai: GLM 5.3 Flash",
      "aliases": [
        "z-ai/glm-5.3-flash",
        "GLM 5.3 Flash",
        "glm-5.3-flash"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-5.3-flash"
    },
    {
      "name": "Z.ai: GLM 5.3 FlashX",
      "aliases": [
        "z-ai/glm-5.3-flashx",
        "GLM 5.3 FlashX",
        "glm-5.3-flashx"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-5.3-flashx"
    },
    {
      "name": "Z.ai: GLM 5.3 Prime",
      "aliases": [
        "z-ai/glm-5.3-prime",
        "GLM 5.3 Prime",
        "glm-5.3-prime"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-5.3-prime"
    },
    {
      "name": "Z.ai: GLM 5V Turbo",
      "aliases": [
        "z-ai/glm-5v-turbo",
        "GLM 5V Turbo",
        "glm-5v-turbo"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "z-ai/glm-5v-turbo"
    },
    {
      "name": "Anthropic: Claude Fable Latest",
      "aliases": [
        "~anthropic/claude-fable-latest",
        "Claude Fable Latest",
        "claude-fable-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~anthropic/claude-fable-latest"
    },
    {
      "name": "Anthropic: Claude Haiku Latest",
      "aliases": [
        "~anthropic/claude-haiku-latest",
        "Claude Haiku Latest",
        "claude-haiku-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~anthropic/claude-haiku-latest"
    },
    {
      "name": "Anthropic: Claude Opus Latest",
      "aliases": [
        "~anthropic/claude-opus-latest",
        "Claude Opus Latest",
        "claude-opus-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~anthropic/claude-opus-latest"
    },
    {
      "name": "Anthropic: Claude Sonnet Latest",
      "aliases": [
        "~anthropic/claude-sonnet-latest",
        "Claude Sonnet Latest",
        "claude-sonnet-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~anthropic/claude-sonnet-latest"
    },
    {
      "name": "DeepSeek: DeepSeek Flash Latest",
      "aliases": [
        "~deepseek/deepseek-flash-latest",
        "DeepSeek Flash Latest",
        "deepseek-flash-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~deepseek/deepseek-flash-latest"
    },
    {
      "name": "DeepSeek: DeepSeek Pro Latest",
      "aliases": [
        "~deepseek/deepseek-pro-latest",
        "DeepSeek Pro Latest",
        "deepseek-pro-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~deepseek/deepseek-pro-latest"
    },
    {
      "name": "DeepSeek: DeepSeek V4 Flash Latest",
      "aliases": [
        "~deepseek/deepseek-v4-flash-latest",
        "DeepSeek V4 Flash Latest",
        "deepseek-v4-flash-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~deepseek/deepseek-v4-flash-latest"
    },
    {
      "name": "Google: Gemini Flash Latest",
      "aliases": [
        "~google/gemini-flash-latest",
        "Gemini Flash Latest",
        "gemini-flash-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~google/gemini-flash-latest"
    },
    {
      "name": "Google: Gemini Pro Latest",
      "aliases": [
        "~google/gemini-pro-latest",
        "Gemini Pro Latest",
        "gemini-pro-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~google/gemini-pro-latest"
    },
    {
      "name": "MoonshotAI: Kimi Latest",
      "aliases": [
        "~moonshotai/kimi-latest",
        "Kimi Latest",
        "kimi-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~moonshotai/kimi-latest"
    },
    {
      "name": "OpenAI: GPT Astra Latest",
      "aliases": [
        "~openai/gpt-astra-latest",
        "GPT Astra Latest",
        "gpt-astra-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~openai/gpt-astra-latest"
    },
    {
      "name": "OpenAI: GPT Luna Latest",
      "aliases": [
        "~openai/gpt-luna-latest",
        "GPT Luna Latest",
        "gpt-luna-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~openai/gpt-luna-latest"
    },
    {
      "name": "OpenAI: GPT Mini Latest",
      "aliases": [
        "~openai/gpt-mini-latest",
        "GPT Mini Latest",
        "gpt-mini-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~openai/gpt-mini-latest"
    },
    {
      "name": "OpenAI: GPT Sol Latest",
      "aliases": [
        "~openai/gpt-sol-latest",
        "GPT Sol Latest",
        "gpt-sol-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~openai/gpt-sol-latest"
    },
    {
      "name": "OpenAI: GPT Terra Latest",
      "aliases": [
        "~openai/gpt-terra-latest",
        "GPT Terra Latest",
        "gpt-terra-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~openai/gpt-terra-latest"
    },
    {
      "name": "Pareto Latest",
      "aliases": [
        "~unbiased/pareto-latest",
        "Pareto Latest",
        "pareto-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~unbiased/pareto-latest"
    },
    {
      "name": "xAI: Grok Latest",
      "aliases": [
        "~x-ai/grok-latest",
        "Grok Latest",
        "grok-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~x-ai/grok-latest"
    },
    {
      "name": "Z.ai: GLM Flash Latest",
      "aliases": [
        "~z-ai/glm-flash-latest",
        "GLM Flash Latest",
        "glm-flash-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~z-ai/glm-flash-latest"
    },
    {
      "name": "Z.ai: GLM Latest",
      "aliases": [
        "~z-ai/glm-latest",
        "GLM Latest",
        "glm-latest"
      ],
      "category": "llm",
      "provenance": "model-directory",
      "source": "https://openrouter.ai/api/v1/models",
      "checkedAt": "2026-10-27",
      "kind": "unknown",
      "min": null,
      "max": null,
      "priceText": "Тариф Weavy не получен",
      "modelId": "~z-ai/glm-latest"
    }
  ]
};
