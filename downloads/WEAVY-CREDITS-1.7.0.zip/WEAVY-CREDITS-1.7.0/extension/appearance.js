// Shared by the content script and options page: one appearance model.
(() => {
  const defaults = Object.freeze({
    accentColor: '#ffffff', bgColor: '#1e1e1e', borderRadius: 11,
    dockButtonSize: 36, dockOpacity: 100, dockBlur: 7, dockShadow: 13, accentMode: 'normal',
    dockShadowSoftness: 13, dockShadowDirection: 90, dockShadowDistance: 3.25,
    dockBorderWidth: 1, dockBorderColor: '#ffffff', dockBorderOpacity: 14,
    settingsBgColor: '#1e1e1e', settingsPanelColor: '#2b2b2b', settingsAccentColor: '#ffffff',
    settingsPatternSpacing: 16, settingsPatternOpacity: 11, settingsPatternEnabled: true
  });
  const ranges = {borderRadius:[0,24], dockButtonSize:[30,42], dockOpacity:[0,100],
    dockBlur:[0,24], dockShadow:[0,48], dockShadowSoftness:[0,80], dockShadowDirection:[0,360], dockShadowDistance:[0,40], dockBorderWidth:[0,6], dockBorderOpacity:[0,100], settingsPatternSpacing:[8,64], settingsPatternOpacity:[0,30]};
  const rgb = hex => [1,3,5].map(i => parseInt(hex.slice(i,i+2),16));
  const foreground = hex => {
    const [r,g,b] = rgb(hex).map(c => {c/=255; return c<=.04045 ? c/12.92 : ((c+.055)/1.055)**2.4;});
    return .2126*r+.7152*g+.0722*b > .179 ? '#16161d' : '#ffffff';
  };
  function normalize(raw = {}) {
    const s = {...defaults, ...raw};
    for (const key of ['accentColor','bgColor','settingsBgColor','settingsPanelColor','settingsAccentColor','dockBorderColor']) {
      if (!/^#[0-9a-f]{6}$/i.test(s[key])) s[key] = defaults[key];
    }
    for (const [key,[min,max]] of Object.entries(ranges)) {
      const value = s[key] == null || s[key] === '' ? NaN : Number(s[key]);
      s[key] = Number.isFinite(value) ? Math.min(max,Math.max(min,value)) : defaults[key];
    }
    if (!['minimal','normal','strong'].includes(s.accentMode)) s.accentMode = defaults.accentMode;
    s.settingsPatternEnabled = s.settingsPatternEnabled !== false;
    return s;
  }
  function apply(target, raw) {
    const s = normalize(raw), color = rgb(s.bgColor), strength = s.dockShadow/48;
    const radians = s.dockShadowDirection * Math.PI / 180;
    const offsetX = +(Math.cos(radians)*s.dockShadowDistance).toFixed(3);
    const offsetY = +(Math.sin(radians)*s.dockShadowDistance).toFixed(3);
    const values = {
      '--wcr-accent':s.accentColor, '--wcr-accent-rgb':rgb(s.accentColor).join(', '),
      '--wcr-on-accent':foreground(s.accentColor), '--wcr-on-bg':foreground(s.bgColor),
      '--wcr-bg':s.bgColor, '--wcr-surface':`rgba(${color.join(', ')}, ${s.dockOpacity/100})`,
      '--wcr-radius':s.borderRadius+'px', '--wcr-button-radius':Math.max(0,s.borderRadius-1)+'px',
      '--wcr-btn-size':s.dockButtonSize+'px', '--wcr-blur':s.dockBlur ? `blur(${s.dockBlur}px)` : 'none',
      '--wcr-border-width':s.dockBorderWidth+'px',
      '--wcr-border-color':`rgba(${rgb(s.dockBorderColor).join(', ')}, ${s.dockBorderOpacity/100})`,
      '--wcr-shadow':s.dockShadow === 0 ? 'none' : `${offsetX}px ${offsetY}px ${s.dockShadowSoftness}px rgba(0,0,0,${.75*strength})`
    };
    for (const [key,value] of Object.entries(values)) target.style.setProperty(key,value);
    if (target.classList.contains('dock') || target.id === 'dock-preview-box') target.dataset.accentMode = s.accentMode;
  }
  const keys = Object.freeze(Object.keys(defaults));
  const snapshot = raw => {const s=normalize(raw);return Object.fromEntries(keys.map(k=>[k,s[k]]));};
  const presets = Object.freeze([
    {id:'builtin-default',name:'Default',values:snapshot(defaults)},
    {id:'builtin-glass',name:'Glass',values:snapshot({...defaults,dockOpacity:68,dockBlur:18,dockShadow:18,dockShadowSoftness:28,dockShadowDistance:8,dockBorderOpacity:22})},
    {id:'builtin-solid',name:'Solid',values:snapshot({...defaults,dockOpacity:100,dockBlur:0,dockShadow:0,dockBorderWidth:1,dockBorderOpacity:30})},
    {id:'builtin-compact',name:'Compact',values:snapshot({...defaults,dockButtonSize:30,borderRadius:8,dockBlur:0,dockShadow:8,dockShadowSoftness:10,dockShadowDistance:2})}
  ]);
  const equal = (a,b) => {const x=normalize(a),y=normalize(b);return keys.every(k=>x[k]===y[k]);};
  const sanitizePresets = value => {
    if (!Array.isArray(value)) return [];
    const ids=new Set();
    return value.filter(p=>p && typeof p.id==='string' && p.id.startsWith('custom-') && !ids.has(p.id) && ids.add(p.id) && typeof p.name==='string' && p.name.trim()).map(p=>({id:p.id,name:p.name.trim().slice(0,60),values:snapshot(p.values||{})}));
  };
  globalThis.CreditsAppearance = Object.freeze({defaults, keys, normalize, apply, foreground, rgb, snapshot, presets, equal, sanitizePresets});
})();

export const APPEARANCE = globalThis.CreditsAppearance;
